-- FOR ONLINE HOSTING: import this file into the database you created in your hosting control panel.
-- (Same as schema.sql, minus the database-creation lines, which shared hosting does not allow.)
-- Tables are created as InnoDB so foreign keys / cascade deletes work (some free hosts default to MyISAM).
-- Enrollment System Database
-- Import this file in phpMyAdmin or via: mysql -u root -p < schema.sql

-- ========== STUDENTS ==========
CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(20) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  birthday DATE NOT NULL,
  gender VARCHAR(20) NOT NULL,
  address VARCHAR(255) NOT NULL,
  contact_number VARCHAR(20) NOT NULL,
  email VARCHAR(100) NOT NULL,
  program VARCHAR(100) NOT NULL,
  campus VARCHAR(50) NOT NULL DEFAULT 'Congressional',
  year_level VARCHAR(20) NOT NULL,
  section_id INT DEFAULT NULL,
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== STAFF ==========
CREATE TABLE staff (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== ADMIN ==========
CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== SECTIONS ==========
CREATE TABLE sections (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  program VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== SUBJECTS ==========
CREATE TABLE subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) UNIQUE NOT NULL,
  name VARCHAR(150) NOT NULL,
  units INT NOT NULL,
  schedule VARCHAR(100) NOT NULL,
  program VARCHAR(100) NOT NULL DEFAULT 'ALL'  -- 'ALL' = common to every course
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== ENROLLMENTS (one row per submission) ==========
CREATE TABLE enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  school_year VARCHAR(20) DEFAULT '2026-2027',
  semester VARCHAR(10) DEFAULT '1st',
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== ENROLLMENT ITEMS (subjects per enrollment) ==========
CREATE TABLE enrollment_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  enrollment_id INT NOT NULL,
  subject_id INT NOT NULL,
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== GRADES ==========
CREATE TABLE grades (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  subject_id INT NOT NULL,
  prelim DECIMAL(5,2) DEFAULT NULL,
  midterm DECIMAL(5,2) DEFAULT NULL,
  final DECIMAL(5,2) DEFAULT NULL,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== SUPERADMIN (manages all accounts) ==========
CREATE TABLE IF NOT EXISTS superadmins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== ACTIVITY LOG (who did what, and when) ==========
CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  actor_role VARCHAR(20) NOT NULL,
  actor_name VARCHAR(100) NOT NULL,
  action VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Password reset links for the "Forgot password" email.
-- Only a SHA-256 hash of the token is stored, so a leaked database can't be used to reset passwords.
CREATE TABLE IF NOT EXISTS password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default superadmin account -> username: superadmin / password: super123
INSERT INTO superadmins (username, password, full_name) VALUES
('superadmin', '$2b$10$03BkHMhMVc3SeVv6meG4MuRm52tQ7U31NZuFGjmYB/X6ncEiNleRC', 'Super Admin');

-- ========== SEED DATA ==========

-- Default staff account -> username: staff1 / password: staff123
INSERT INTO staff (username, password, full_name) VALUES
('staff1', '$2y$10$oHelST5m4AfuRHklmfEodOvYwlu5puG6DFppAkBSOqbJ7mQLncgV.', 'Staff One');

-- Default admin account -> username: admin1 / password: admin123
INSERT INTO admins (username, password, full_name) VALUES
('admin1', '$2y$10$cCRk/.tNOgMk0gIpOr6gBupkKgkpIweQB9tA2Qjm4IsDpy859tsNG', 'Admin One');

-- Sample sections
INSERT INTO sections (name, program) VALUES
('BSIT 1-A','BSIT'), ('BSIT 1-B','BSIT'), ('BSCS 1-A','BSCS'),
('BSCRIM 1-A','BSCRIM'), ('BSA 1-A','BSA');

-- Sample subjects
INSERT INTO subjects (code, name, units, schedule, program) VALUES
('IT101','Intro to Computing',3,'MWF 8:00-9:00','BSIT'),
('MATH102','Discrete Mathematics',3,'TTh 10:00-11:30','CSD'),
('ENG101','Purposive Communication',3,'MWF 1:00-2:00','ALL'),
('IT103','Programming 1',4,'TTh 1:00-3:00','BSIT'),
('PE101','Physical Education',2,'Sat 8:00-10:00','ALL');

-- Minor subjects (also available as sql/add_minor_subjects.sql for existing databases)
INSERT INTO subjects (code, name, units, schedule, program) VALUES
('UTS101','Understanding the Self',3,'MWF 10:00-11:00','ALL'),
('CS103','Programming 1',4,'TTh 1:00-3:00','BSCS'),
('IS103','Programming 1',4,'TTh 1:00-3:00','BSIS'),
('EMC103','Programming 1 (EMC)',4,'TTh 3:00-5:00','BSEMC'),
-- Camarin campus starter subjects (sample - replace with the real curriculum)
('CRIM101','Introduction to Criminology',3,'MWF 8:00-9:00','BSCRIM'),
('CRIM102','Philippine Criminal Justice System',3,'TTh 8:00-9:30','BSCRIM'),
('CRIM103','Law Enforcement Organization and Administration',3,'MWF 10:00-11:00','BSCRIM'),
('ACCT101','Fundamentals of Accounting',3,'MWF 8:00-9:00','BSA'),
('ACCT102','Business Mathematics',3,'TTh 8:00-9:30','BSA'),
('ACCT103','Basic Microeconomics',3,'MWF 10:00-11:00','BSA');

-- Sample approved student -> Student ID: 20250775-C / password: student123
INSERT INTO students (student_id, password, full_name, birthday, gender, address, contact_number, email, program, year_level, section_id, status) VALUES
('20250775-C', '$2y$10$tbTZpq5dUwTGYWIgUKWzHuIWHY6D9PjeU5MbjpDTlMi41X7vS8ECq', 'Juan Dela Cruz', '2007-03-14', 'Male', 'Quezon City', '09170000000', 'juan@email.com', 'BSIT', '1st Year', 1, 'approved');

-- Sample pending student (waiting for Staff approval) -> Student ID: 20260101-C
INSERT INTO students (student_id, password, full_name, birthday, gender, address, contact_number, email, program, year_level, status) VALUES
('20260101-C', '$2y$10$tbTZpq5dUwTGYWIgUKWzHuIWHY6D9PjeU5MbjpDTlMi41X7vS8ECq', 'Mika Torres', '2008-01-20', 'Female', 'Antipolo City', '09171234567', 'mika@email.com', 'BSIT', '1st Year', 'pending');

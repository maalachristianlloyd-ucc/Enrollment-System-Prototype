-- Run this ONCE in phpMyAdmin (SQL tab) on your existing database.
USE enrollment_system;

ALTER TABLE subjects
  ADD COLUMN program VARCHAR(100) NOT NULL DEFAULT 'ALL' AFTER schedule;

-- Put existing subjects under the right course.
-- ENG101, MATH102, PE101 stay 'ALL' (common to every course).
UPDATE subjects SET program = 'BSIT' WHERE code IN ('IT101', 'IT103');

-- Run this ONLY if you already imported schema.sql before superadmin was added.
USE enrollment_system;

-- ========== SUPERADMIN (manages all accounts) ==========
CREATE TABLE IF NOT EXISTS superadmins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL
);

-- ========== ACTIVITY LOG (who did what, and when) ==========
CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  actor_role VARCHAR(20) NOT NULL,
  actor_name VARCHAR(100) NOT NULL,
  action VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default superadmin account -> username: superadmin / password: super123
INSERT INTO superadmins (username, password, full_name) VALUES
('superadmin', '$2b$10$03BkHMhMVc3SeVv6meG4MuRm52tQ7U31NZuFGjmYB/X6ncEiNleRC', 'Super Admin');

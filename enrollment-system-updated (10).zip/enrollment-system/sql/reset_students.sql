-- FRESH START FOR THE DEMO
-- Removes EVERY student and everything tied to students (enrollments, selected subjects, grades).
-- KEEPS: admin, staff and superadmin accounts, subjects, and sections.
--
-- How to run: phpMyAdmin -> click your database (enrollment_system) -> "SQL" tab -> paste this -> Go.
-- (There is no USE line on purpose, so it works on your PC and on the online hosting.)
-- This cannot be undone. Click "Export" first if you want a backup.

DELETE FROM enrollment_items;
DELETE FROM enrollments;
DELETE FROM grades;
DELETE FROM students;

-- Optional: also empty the activity log for a clean demo (remove the two dashes in front to run it)
-- DELETE FROM activity_logs;

-- Start the counters again from 1
ALTER TABLE enrollment_items AUTO_INCREMENT = 1;
ALTER TABLE enrollments      AUTO_INCREMENT = 1;
ALTER TABLE grades           AUTO_INCREMENT = 1;
ALTER TABLE students         AUTO_INCREMENT = 1;

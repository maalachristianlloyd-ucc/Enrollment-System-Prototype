-- CAMARIN CAMPUS: adds BS Criminology (BSCRIM) and BS Accountancy (BSA) with starter sections and subjects.
-- Run ONCE on an existing database: phpMyAdmin -> your database -> Import (or SQL tab).
-- Safe to run twice: sections are only added if missing, and subjects are skipped if the code already exists.
-- (No USE line, so it also works on the online hosting.)

-- Discrete Mathematics is for the CSD programs only (BSIT, BSCS, BSIS, BSEMC), not for Criminology/Accountancy.
UPDATE subjects SET program = 'CSD' WHERE code = 'MATH102' AND program = 'ALL';

-- Starter sections
INSERT INTO sections (name, program)
SELECT 'BSCRIM 1-A', 'BSCRIM' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM sections WHERE name = 'BSCRIM 1-A');
INSERT INTO sections (name, program)
SELECT 'BSA 1-A', 'BSA' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM sections WHERE name = 'BSA 1-A');

-- Starter subjects (sample names and schedules - replace with the real curriculum in Admin > Subjects)
INSERT IGNORE INTO subjects (code, name, units, schedule, program) VALUES
('CRIM101','Introduction to Criminology',3,'MWF 8:00-9:00','BSCRIM'),
('CRIM102','Philippine Criminal Justice System',3,'TTh 8:00-9:30','BSCRIM'),
('CRIM103','Law Enforcement Organization and Administration',3,'MWF 10:00-11:00','BSCRIM'),
('ACCT101','Fundamentals of Accounting',3,'MWF 8:00-9:00','BSA'),
('ACCT102','Business Mathematics',3,'TTh 8:00-9:30','BSA'),
('ACCT103','Basic Microeconomics',3,'MWF 10:00-11:00','BSA');

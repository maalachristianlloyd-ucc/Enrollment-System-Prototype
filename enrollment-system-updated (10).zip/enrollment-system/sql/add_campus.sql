-- Run this ONLY if your database already exists (schema.sql was imported before).
-- Adds the Campus field to the students table.
USE enrollment_system;

ALTER TABLE students
  ADD COLUMN campus VARCHAR(50) NOT NULL DEFAULT 'Congressional' AFTER program;

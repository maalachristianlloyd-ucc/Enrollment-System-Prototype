-- Run ONCE in phpMyAdmin (select the enrollment_system database -> SQL tab -> paste -> Go).
-- INSERT IGNORE skips any subject code that already exists, so running it twice is safe.
USE enrollment_system;

INSERT IGNORE INTO subjects (code, name, units, schedule, program) VALUES
-- Common to every course
('UTS101', 'Understanding the Self',      3, 'MWF 10:00-11:00', 'ALL'),

-- Programming 1: BSIT already has IT103. Added for BSCS and BSIS.
('CS103',  'Programming 1',               4, 'TTh 1:00-3:00',   'BSCS'),
('IS103',  'Programming 1',               4, 'TTh 1:00-3:00',   'BSIS'),

-- BSEMC has its own programming subject (placeholder name/schedule - rename in Admin > Subjects if needed)
('EMC103', 'Programming 1 (EMC)',         4, 'TTh 3:00-5:00',   'BSEMC');

-- Purposive Communication already exists as ENG101 (program = ALL), so every course already gets it.

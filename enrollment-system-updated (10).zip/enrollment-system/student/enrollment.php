<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('student');
$role = 'student'; $active = 'Enrollment';
$sid = (int)$_SESSION['id'];
$MAX_UNITS = 30;
$error = '';

$p = $conn->prepare("SELECT program FROM students WHERE id = ?");
$p->bind_param("i", $sid); $p->execute();
$prog = $p->get_result()->fetch_assoc()['program'];

if (!isset($_SESSION['enroll_step'])) $_SESSION['enroll_step'] = 1;
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

// Does the student already have a submitted enrollment?
$ex = $conn->prepare("SELECT * FROM enrollments WHERE student_id = ? ORDER BY id DESC LIMIT 1");
$ex->bind_param("i", $sid); $ex->execute();
$existing = $ex->get_result()->fetch_assoc();
$alreadySubmitted = $existing && in_array($existing['status'], ['pending', 'approved']);

// Returns the subjects (id, units) from $ids that the student is allowed to take.
function allowed_subjects($conn, array $ids, $prog) {
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn($i) => $i > 0)));
    if (!$ids) return [];
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("SELECT id, units FROM subjects WHERE id IN ($marks) AND program IN (?, 'ALL', ?)");
    $types = str_repeat('i', count($ids)) . 'ss';
    $args = array_merge($ids, [$prog, program_group($prog) ?: $prog]);
    $stmt->bind_param($types, ...$args);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$alreadySubmitted) {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'select') {
        $rows = allowed_subjects($conn, (array)($_POST['subjects'] ?? []), $prog);
        $units = array_sum(array_column($rows, 'units'));
        if (!$rows) {
            $error = 'Please select at least one subject.';
        } elseif ($units > $MAX_UNITS) {
            $error = "You selected $units units. The maximum load is $MAX_UNITS units.";
        } else {
            $_SESSION['cart'] = array_map('intval', array_column($rows, 'id'));
            $_SESSION['enroll_step'] = 2;
        }
    } elseif ($action === 'back') {
        $_SESSION['enroll_step'] = 1;
    } elseif ($action === 'submit') {
        $rows = allowed_subjects($conn, $_SESSION['cart'], $prog);
        if (!$rows) {
            $error = 'Your subject list is empty. Please select your subjects again.';
            $_SESSION['enroll_step'] = 1;
        } else {
            $conn->begin_transaction();
            $stmt = $conn->prepare("INSERT INTO enrollments (student_id, status) VALUES (?, 'pending')");
            $stmt->bind_param("i", $sid); $stmt->execute();
            $enrollId = $conn->insert_id;
            $item = $conn->prepare("INSERT INTO enrollment_items (enrollment_id, subject_id) VALUES (?, ?)");
            foreach ($rows as $r) {
                $subjId = (int)$r['id'];
                $item->bind_param("ii", $enrollId, $subjId);
                $item->execute();
            }
            $conn->commit();
            log_activity($conn, "Submitted enrollment");
            $_SESSION['enroll_step'] = 3;
            $existing = ['id' => $enrollId, 'status' => 'pending'];
            $alreadySubmitted = true;
        }
    }
}

if (!$alreadySubmitted && $_SESSION['enroll_step'] == 3) $_SESSION['enroll_step'] = 1; // e.g. previous request was rejected
$step = $alreadySubmitted ? 3 : $_SESSION['enroll_step'];
$grp = program_group($prog) ?: $prog;
$subjStmt = $conn->prepare("SELECT * FROM subjects WHERE program IN (?, 'ALL', ?) ORDER BY code");
$subjStmt->bind_param("ss", $prog, $grp);
$subjStmt->execute();
$subjects = $subjStmt->get_result()->fetch_all(MYSQLI_ASSOC);

$cartSubjects = [];
if ($step == 2 && !empty($_SESSION['cart'])) {
    $ids = array_map('intval', $_SESSION['cart']);
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $conn->prepare("SELECT * FROM subjects WHERE id IN ($marks) ORDER BY code");
    $stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
    $stmt->execute();
    $cartSubjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
echo page_head('Enrollment');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Enrollment</h1><span class="badge">Student Portal</span></div>

  <div class="steps">
    <span class="<?= $step==1?'on':'' ?>">1 Select Subjects</span>
    <span class="<?= $step==2?'on':'' ?>">2 Review</span>
    <span class="<?= $step==3?'on':'' ?>">3 Confirmation</span>
  </div>
  <?php if ($error): ?><div class="err" role="alert" style="margin:0 0 12px"><?= e($error) ?></div><?php endif; ?>

  <?php if ($step == 1): ?>
    <div class="card">
      <div class="toolbar">
        <div class="search"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="search" id="subjFilter" placeholder="Filter subjects" aria-label="Filter subjects"></div>
        <span class="mu" id="unitCount" style="margin-left:auto"></span>
      </div>
      <form method="POST" id="selForm">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="select">
        <div class="tw"><table id="subjTable">
          <tr><th></th><th>Code</th><th>Subject</th><th>Units</th><th>Schedule</th></tr>
          <?php foreach ($subjects as $s): ?>
            <tr>
              <td><input type="checkbox" name="subjects[]" value="<?= (int)$s['id'] ?>" data-units="<?= (int)$s['units'] ?>" style="width:auto"
                <?= in_array((int)$s['id'], $_SESSION['cart']) ? 'checked' : '' ?>></td>
              <td><?= e($s['code']) ?></td><td><?= e($s['name']) ?></td><td><?= e($s['units']) ?></td><td><?= e($s['schedule']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$subjects): ?><tr><td colspan="5" class="mu" style="text-align:center;padding:26px">No subjects are available for your course yet.</td></tr><?php endif; ?>
        </table></div>
        <div class="field-err" id="selErr">Please select at least one subject.</div>
        <br><button type="submit">Next</button>
      </form>
    </div>
    <script>
    (function () {
      var max = <?= (int)$MAX_UNITS ?>;
      var boxes = document.querySelectorAll('#subjTable input[type=checkbox]');
      var out = document.getElementById('unitCount'), err = document.getElementById('selErr');
      function total() { var t = 0; boxes.forEach(function (b) { if (b.checked) t += +b.dataset.units; }); return t; }
      function update() { var t = total(); out.textContent = t + ' / ' + max + ' units selected'; out.style.color = t > max ? 'var(--er)' : ''; }
      boxes.forEach(function (b) { b.addEventListener('change', function () { update(); err.classList.remove('show'); }); });
      update();
      document.getElementById('subjFilter').addEventListener('input', function () {
        var q = this.value.toLowerCase();
        document.querySelectorAll('#subjTable tr').forEach(function (tr, i) { if (i) tr.style.display = tr.textContent.toLowerCase().indexOf(q) > -1 ? '' : 'none'; });
      });
      document.getElementById('selForm').addEventListener('submit', function (ev) {
        var t = total();
        if (t === 0) { err.textContent = 'Please select at least one subject.'; err.classList.add('show'); ev.preventDefault(); }
        else if (t > max) { err.textContent = 'Maximum load is ' + max + ' units. You selected ' + t + '.'; err.classList.add('show'); ev.preventDefault(); }
      });
    })();
    </script>

  <?php elseif ($step == 2): ?>
    <div class="card">
      <h3>Review Enrollment</h3>
      <div class="tw"><table>
        <tr><th>Code</th><th>Subject</th><th>Units</th></tr>
        <?php foreach ($cartSubjects as $s): ?>
          <tr><td><?= e($s['code']) ?></td><td><?= e($s['name']) ?></td><td><?= e($s['units']) ?></td></tr>
        <?php endforeach; ?>
        <tr><td></td><td><b>Total</b></td><td><b><?= (int)array_sum(array_column($cartSubjects, 'units')) ?></b></td></tr>
      </table></div>
      <br>
      <form method="POST" class="inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="back"><button class="sec" type="submit">Edit Subjects</button></form>
      <form method="POST" class="inline-form" data-confirm="Submit your enrollment with these subjects? You won't be able to change them after submitting." data-confirm-title="Submit enrollment" data-confirm-btn="Submit"><?= csrf_field() ?><input type="hidden" name="action" value="submit"><button type="submit">Submit Enrollment</button></form>
    </div>

  <?php else: ?>
    <div class="card">
      <h2 class="ok">✔ Enrollment Submitted</h2>
      <div class="mu"><?= $existing && $existing['status'] === 'approved' ? 'Your enrollment is approved.' : 'Waiting for Admin approval.' ?></div>
      <br><a class="btn" href="schedule.php">View Schedule</a>
    </div>
    <?php unset($_SESSION['cart']); ?>
  <?php endif; ?>
</div>
</div></body></html>

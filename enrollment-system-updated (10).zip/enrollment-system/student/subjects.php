<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('student');
$role = 'student'; $active = 'Subject List';
$sid = (int)$_SESSION['id'];
$p = $conn->prepare("SELECT program FROM students WHERE id = ?");
$p->bind_param("i", $sid); $p->execute();
$prog = $p->get_result()->fetch_assoc()['program'];

$lt = list_query($conn, [
    'select'   => '*',
    'from'     => 'subjects',
    'where'    => ["program IN (?, 'ALL', ?)"],
    'params'   => [$prog, program_group($prog) ?: $prog], 'types' => 'ss',
    'search'   => ['code', 'name', 'schedule'],
    'sortable' => ['code' => 'code', 'name' => 'name', 'units' => 'units', 'schedule' => 'schedule'],
    'default_sort' => 'code',
]);
echo page_head('Subject List');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Subject List</h1><span class="badge">Student Portal</span></div>
  <div class="card">
    <?= list_toolbar($lt, 'Search code, subject or schedule') ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'code', 'Code') ?><?= sort_th($lt, 'name', 'Subject') ?><?= sort_th($lt, 'units', 'Units') ?><?= sort_th($lt, 'schedule', 'Schedule') ?></tr>
      <?php if (!$lt['rows']) echo empty_row(4, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $s): ?>
        <tr><td><?= e($s['code']) ?></td><td><?= e($s['name']) ?></td><td><?= e($s['units']) ?></td><td><?= e($s['schedule']) ?></td></tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
</div>
</div></body></html>

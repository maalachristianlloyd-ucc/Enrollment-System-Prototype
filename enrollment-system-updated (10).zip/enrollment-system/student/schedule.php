<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('student');
$role = 'student'; $active = 'My Schedule';
$sid = $_SESSION['id'];

$enr = $conn->query("SELECT * FROM enrollments WHERE student_id = $sid AND status='approved' ORDER BY id DESC LIMIT 1")->fetch_assoc();
$subjects = null;
if ($enr) {
    $subjects = $conn->query("SELECT sub.* FROM enrollment_items ei JOIN subjects sub ON ei.subject_id = sub.id WHERE ei.enrollment_id = {$enr['id']}");
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>My Schedule</title><link rel="stylesheet" href="<?= BASE_PATH ?>/assets/css/style.css"></head>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>My Schedule</h1><span class="badge">Student Portal</span></div>
  <div class="card">
    <?php if ($subjects): ?>
      <div class="tw"><table>
        <tr><th>Code</th><th>Subject</th><th>Schedule</th></tr>
        <?php while ($s = $subjects->fetch_assoc()): ?>
          <tr><td><?= e($s['code']) ?></td><td><?= e($s['name']) ?></td><td><?= e($s['schedule']) ?></td></tr>
        <?php endwhile; ?>
      </table></div>
    <?php else: ?>
      <span class="mu">No schedule yet. Your enrollment must be approved by Admin first.</span>
    <?php endif; ?>
  </div>
</div>
</div></body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('student');
$role = 'student'; $active = 'Dashboard';

$sid = $_SESSION['id'];
$stu = $conn->query("SELECT s.*, sec.name AS section_name FROM students s LEFT JOIN sections sec ON s.section_id = sec.id WHERE s.id = $sid")->fetch_assoc();

$enr = $conn->query("SELECT e.id, e.status FROM enrollments e WHERE e.student_id = $sid ORDER BY e.id DESC LIMIT 1")->fetch_assoc();
$enrolled = $enr && $enr['status'] === 'approved';

$units = 0; $subjCount = 0;
if ($enr) {
    $res = $conn->query("SELECT SUM(sub.units) u, COUNT(*) c FROM enrollment_items ei JOIN subjects sub ON ei.subject_id = sub.id WHERE ei.enrollment_id = {$enr['id']}");
    $row = $res->fetch_assoc();
    $units = $row['u'] ?? 0; $subjCount = $row['c'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>Dashboard</title><link rel="stylesheet" href="<?= BASE_PATH ?>/assets/css/style.css"></head>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Dashboard</h1><span class="badge">Student Portal</span></div>

  <div class="hero">
    <h2 style="margin:0 0 6px">Welcome, <?= e($stu['full_name']) ?>!</h2>
    <div>Enrollment status:
      <b><?= $enrolled ? 'Enrolled' : ($enr && $enr['status']==='pending' ? 'Pending Admin approval' : 'Not yet enrolled') ?></b>
    </div>
  </div>

  <div class="grid">
    <div class="card"><div class="mu">Section</div><div class="num"><?= e($stu['section_name'] ?? 'Unassigned') ?></div></div>
    <div class="card"><div class="mu">Subjects</div><div class="num"><?= $subjCount ?></div></div>
    <div class="card"><div class="mu">Units</div><div class="num"><?= $units ?></div></div>
  </div>

  <div class="card">
    <h3>Next</h3>
    <?= $enrolled ? 'Check your schedule.' : ($enr && $enr['status']==='pending' ? 'Your enrollment is waiting for Admin approval.' : 'Go to Enrollment to pick your subjects.') ?>
    <br><br>
    <a class="btn" href="<?= $enrolled ? 'schedule.php' : 'enrollment.php' ?>"><?= $enrolled ? 'My Schedule' : 'Start Enrollment' ?></a>
  </div>
</div>
</div></body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('student');
$role = 'student'; $active = 'My Grades';
$sid = $_SESSION['id'];
$grades = $conn->query("SELECT sub.code, sub.name, g.prelim, g.midterm, g.final FROM grades g JOIN subjects sub ON g.subject_id = sub.id WHERE g.student_id = $sid");
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>My Grades</title><link rel="stylesheet" href="<?= BASE_PATH ?>/assets/css/style.css"></head>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>My Grades</h1><span class="badge">Student Portal</span></div>
  <div class="card">
    <div class="tw"><table>
      <tr><th>Subject</th><th>Prelim</th><th>Midterm</th><th>Final</th></tr>
      <?php if ($grades->num_rows === 0): ?>
        <tr><td colspan="4" class="mu">No grades recorded yet.</td></tr>
      <?php endif; ?>
      <?php while ($g = $grades->fetch_assoc()): ?>
        <tr>
          <td><?= e($g['code']) ?> - <?= e($g['name']) ?></td>
          <td><?= e($g['prelim'] ?? '—') ?></td>
          <td><?= e($g['midterm'] ?? '—') ?></td>
          <td><?= e($g['final'] ?? '—') ?></td>
        </tr>
      <?php endwhile; ?>
    </table></div>
    <p class="mu">View only. Grade entries are managed by Staff.</p>
  </div>
</div>
</div></body></html>

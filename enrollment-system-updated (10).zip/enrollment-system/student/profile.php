<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('student');
$role = 'student'; $active = 'My Profile';
$sid = (int)$_SESSION['id'];
$error = '';

$q = $conn->prepare("SELECT * FROM students WHERE id = ?");
$q->bind_param("i", $sid); $q->execute();
$stu = $q->get_result()->fetch_assoc();
$form = ['full_name' => $stu['full_name'], 'address' => $stu['address'], 'contact_number' => $stu['contact_number'], 'email' => $stu['email']];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $form = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'address' => trim($_POST['address'] ?? ''),
        'contact_number' => trim($_POST['contact_number'] ?? ''),
        'email' => strtolower(trim($_POST['email'] ?? '')),
    ];
    $error = first_error([
        v_name($form['full_name']),
        v_address($form['address']),
        v_phone($form['contact_number']),
        v_email($form['email']),
    ]);
    if (!$error) {
        $dup = $conn->prepare("SELECT id FROM students WHERE email = ? AND id <> ? AND status <> 'rejected'");
        $dup->bind_param("si", $form['email'], $sid); $dup->execute();
        if ($dup->get_result()->fetch_assoc()) $error = 'That email is already used by another account.';
    }
    if (!$error) {
        $stmt = $conn->prepare("UPDATE students SET full_name=?, address=?, contact_number=?, email=? WHERE id=?");
        $stmt->bind_param("ssssi", $form['full_name'], $form['address'], $form['contact_number'], $form['email'], $sid);
        $stmt->execute();
        $_SESSION['full_name'] = $form['full_name'];
        flash_set('ok', 'Profile updated.');
        redirect_back();
    }
}
echo page_head('My Profile');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>My Profile</h1><span class="badge">Student Portal</span></div>
  <?= flash_show() ?>
  <?php if ($error): ?><div class="err" role="alert" style="margin:0 0 12px"><?= e($error) ?></div><?php endif; ?>

  <div class="card">
    <form method="POST" novalidate data-confirm="Save the changes to your profile?" data-confirm-title="Update profile" data-confirm-btn="Save">
      <?= csrf_field() ?>
      <table>
        <tr><th>Field</th><th>Information</th></tr>
        <tr><td>Student ID</td><td><?= e($stu['student_id']) ?></td></tr>
        <tr><td>Full Name</td><td><input name="full_name" maxlength="100" value="<?= e($form['full_name']) ?>" required
              oninput="this.value=this.value.replace(/[^\p{L}\s.'\-]/gu,'')"></td></tr>
        <tr><td>Birthday</td><td><?= e($stu['birthday']) ?></td></tr>
        <tr><td>Gender</td><td><?= e($stu['gender']) ?></td></tr>
        <tr><td>Address</td><td><input name="address" maxlength="255" value="<?= e($form['address']) ?>" required></td></tr>
        <tr><td>Contact Number</td><td><input name="contact_number" type="tel" inputmode="numeric" maxlength="11" pattern="09[0-9]{9}"
              title="11 digits starting with 09" value="<?= e($form['contact_number']) ?>" required
              oninput="this.value=this.value.replace(/[^0-9]/g,'')"></td></tr>
        <tr><td>Email</td><td><input name="email" type="email" maxlength="100" value="<?= e($form['email']) ?>" required></td></tr>
        <tr><td>Course / Year</td><td><?= e($stu['program']) ?> / <?= e($stu['year_level']) ?></td></tr>
      </table>
      <br><button type="submit">Save Changes</button>
    </form>
  </div>
</div>
</div></body></html>

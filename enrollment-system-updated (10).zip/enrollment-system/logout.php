<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
$role = $_SESSION['role'] ?? 'student';
if (isset($_SESSION['role'])) log_activity($conn, "Logged out");
$_SESSION = [];
session_destroy();
header("Location: " . login_url_for($role));
exit;

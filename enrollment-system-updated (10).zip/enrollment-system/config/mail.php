<?php
// ======================================================================
// EMAIL SETTINGS (used by "Forgot password" to send the reset link)
// ----------------------------------------------------------------------
// Step 1  Use a Gmail account for the school system (e.g. ucc.enrollment@gmail.com).
// Step 2  Google Account > Security > turn ON "2-Step Verification".
// Step 3  Google Account > Security > "App passwords" > create one (name it "Enrollment").
//         Google shows a 16-letter code. Paste it as MAIL_PASSWORD below.
//         (Use the app password, NOT your normal Gmail password.)
// Step 4  Set MAIL_ENABLED to true.
// ======================================================================
define('MAIL_ENABLED',  false);                       // <- change to true when done
define('MAIL_HOST',     'smtp.gmail.com');
define('MAIL_PORT',     587);
define('MAIL_USERNAME', 'yourschool@gmail.com');      // the Gmail address
define('MAIL_PASSWORD', 'xxxx xxxx xxxx xxxx');       // the 16-letter app password
define('MAIL_FROM_NAME','University Enrollment System');

// The address students open the site from. The reset link in the email starts with this (no slash at the end).
// On XAMPP:  http://localhost/enrollment-system
// ONLINE:    https://your-site.example.com   <- change this when you put the system online!
define('BASE_URL', 'http://localhost/enrollment-system');

define('RESET_LINK_MINUTES', 30);   // how long a reset link works
define('MAIL_DEBUG', true);         // true = show the real email error on screen (set false when live)

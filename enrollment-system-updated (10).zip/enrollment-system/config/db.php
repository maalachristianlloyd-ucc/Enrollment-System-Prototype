<?php
// Database connection settings.
// The system picks the right set automatically:
//   - running on YOUR PC (XAMPP)  -> the first set
//   - running ONLINE (hosting)    -> the second set (values from the hosting control panel)
// Windows = your own XAMPP PC (hosting servers run Linux). This also covers opening the site
// from another laptop over the LAN, e.g. http://192.168.1.5/enrollment-system
$__onMyPc = (DIRECTORY_SEPARATOR === '\\')
         || in_array($_SERVER['SERVER_ADDR'] ?? '', ['127.0.0.1', '::1'], true)
         || in_array($_SERVER['SERVER_NAME'] ?? 'localhost', ['localhost', '127.0.0.1', '::1'], true);

if ($__onMyPc) {
    $DB_HOST = "localhost";
    $DB_USER = "root";
    $DB_PASS = "";
    $DB_NAME = "enrollment_system";
} else {
    $DB_HOST = "sql206.infinityfree.com";
    $DB_USER = "if0_43189906";
    $DB_PASS = "PASTE-YOUR-HOSTING-PASSWORD-HERE";
    $DB_NAME = "if0_43189906_enrollment";
}

try {
    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    if ($conn->connect_error) throw new Exception($conn->connect_error);
    $conn->set_charset('utf8mb4');
} catch (Throwable $ex) {
    error_log('DB connection failed: ' . $ex->getMessage());
    http_response_code(500);
    die($__onMyPc
        ? 'Database connection failed: ' . htmlspecialchars($ex->getMessage()) . '<br>Make sure MySQL is running and you imported sql/schema.sql'
        : 'The system is temporarily unavailable. Please try again in a few minutes.');
}

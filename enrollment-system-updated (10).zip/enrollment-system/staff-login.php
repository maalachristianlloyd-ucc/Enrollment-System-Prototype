<?php
// STAFF / ADMIN LOGIN — students cannot sign in here.
// (Superadmin also uses this page.) Students use index.php.
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

if (isset($_SESSION['role'])) { header("Location: " . dashboard_url_for($_SESSION['role'])); exit; }

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $username = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';

    if (login_locked()) {
        $error = 'Too many failed attempts. Please wait ' . ceil(LOGIN_LOCK_SECONDS / 60) . ' minutes and try again.';
    } elseif ($username === '' || $pass === '') {
        $error = 'Please enter your username and password.';
    } elseif (!preg_match('/^[A-Za-z0-9_.]{1,30}$/', $username) || strlen($pass) > 72) {
        login_failed();
        $error = 'Invalid username or password.';
    } else {
        // Check each staff-side table. Students are NOT checked here.
        $tables = ['staff' => 'staff', 'admins' => 'admin', 'superadmins' => 'superadmin'];
        $matched = null;
        foreach ($tables as $table => $role) {
            $stmt = $conn->prepare("SELECT * FROM $table WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            if ($row && password_verify($pass, $row['password'])) { $matched = [$role, $row]; break; }
        }

        if ($matched) {
            [$role, $row] = $matched;
            session_regenerate_id(true);
            login_reset();
            $_SESSION['role'] = $role;
            $_SESSION['id'] = $row['id'];
            $_SESSION['full_name'] = $row['full_name'];
            log_activity($conn, "Logged in");
            header("Location: $role/dashboard.php");
            exit;
        }
        login_failed();
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Staff Log in · University Enrollment Portal</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="stylesheet" href="assets/css/style.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head><body>
<div class="split">
  <div class="left">
    <div class="brand">
      <img class="logo-img" src="assets/img/logo.png" alt="School logo" width="44" height="44">
      <div><b>University Enrollment System</b><small>Staff &amp; Admin Portal</small></div>
    </div>
    <div>
      <span class="eyebrow hide-sm">Authorized Personnel</span>
      <h1>Manage enrollment with confidence.</h1>
      <div class="mu-dark hide-sm">Approve registrations, review enrollment requests and keep student records up to date.</div>
      <ul class="feat hide-sm">
        <li>Staff: approve new student registrations</li>
        <li>Admin: approve enrollments, manage subjects &amp; sections</li>
        <li>All sign-ins are recorded in the activity log</li>
      </ul>
    </div>
    <div class="info-box hide-sm">
      <div class="mu-dark">Are you a student?</div>
      <div style="margin-top:6px"><a href="index.php" style="color:#ffb26b">Go to the Student login →</a></div>
    </div>
  </div>
  <div class="right"><div class="box">
    <div class="box-head">
      <span class="eyebrow">Staff / Admin Login</span>
      <h1>Sign in</h1>
      <div class="mu">Use the username given to you by the Superadmin.</div>
    </div>
    <?php if ($error): ?><div class="err" role="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" id="loginForm" novalidate style="margin-top:8px">
      <?= csrf_field() ?>
      <label for="username">Username</label>
      <input id="username" name="username" placeholder="e.g. staff1" maxlength="30" autocomplete="username"
             value="<?= e($username) ?>" autofocus required>
      <div class="field-err" data-for="username">Please enter your username.</div>
      <label for="password">Password</label>
      <input id="password" name="password" type="password" data-pw maxlength="72" autocomplete="current-password" placeholder="Enter your password" required>
      <div class="field-err" data-for="password">Please enter your password.</div>
      <button class="full" type="submit">Log in</button>
    </form>
    <div class="auth-foot mu">Student? <a href="index.php">Go to the Student login</a></div>
  </div></div>
</div>
<script src="assets/js/password.js"></script>
<script>
document.getElementById('loginForm').addEventListener('submit', function (ev) {
  var bad = false;
  ['username', 'password'].forEach(function (n) {
    var el = document.getElementById(n), msg = document.querySelector('[data-for="' + n + '"]');
    var empty = el.value.trim() === '';
    el.classList.toggle('invalid', empty); msg.classList.toggle('show', empty);
    if (empty) bad = true;
  });
  if (bad) ev.preventDefault();
});
</script>
</body></html>

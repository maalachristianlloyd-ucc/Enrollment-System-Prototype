<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

$error = '';
$newId = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $full_name = trim($_POST['full_name'] ?? '');
    $birthday = $_POST['birthday'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $address = trim($_POST['address'] ?? '');
    $contact = trim($_POST['contact_number'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $program = trim($_POST['program'] ?? '');
    $campus = trim($_POST['campus'] ?? '');
    $year_level = '1st Year'; // freshmen only
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $programs = program_codes();
    $error = first_error([
        v_name($full_name),
        v_birthday($birthday),
        v_in($gender, ['Male', 'Female', 'Other'], 'gender'),
        v_address($address),
        v_phone($contact),
        v_email($email),
        v_in($program, $programs, 'course / program'),
        v_in($campus, campuses(), 'campus'),
        (isset(program_catalog()[$program]) && in_array($campus, campuses(), true) && program_catalog()[$program]['campus'] !== $campus)
            ? "That course is not offered at the $campus campus." : '',
        v_password($password),
        ($password !== $confirm) ? 'Passwords do not match.' : '',
    ]);

    // Don't allow the same email to register twice
    if (!$error) {
        $dup = $conn->prepare("SELECT id FROM students WHERE email = ? AND status <> 'rejected'");
        $dup->bind_param("s", $email);
        $dup->execute();
        if ($dup->get_result()->num_rows > 0) $error = 'That email is already registered.';
    }

    if ($error) {
        // fall through and show the error
    } else {
        // Generate Student ID: YEAR + 4-digit random number + letter
        // Camarin campus always uses letter "D"; Congressional uses the program's first letter
        $year = date('Y');
        $letter = ($campus === 'Camarin') ? 'D' : strtoupper(substr($program, 0, 1));
        do {
            $num = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
            $studentId = $year . $num . '-' . $letter;
            $check = $conn->prepare("SELECT id FROM students WHERE student_id = ?");
            $check->bind_param("s", $studentId);
            $check->execute();
            $exists = $check->get_result()->num_rows > 0;
        } while ($exists);

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO students (student_id, password, full_name, birthday, gender, address, contact_number, email, program, campus, year_level, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,'pending')");
        $stmt->bind_param("sssssssssss", $studentId, $hash, $full_name, $birthday, $gender, $address, $contact, $email, $program, $campus, $year_level);

        if ($stmt->execute()) {
            $newId = $studentId;
        } else {
            $error = 'Something went wrong. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>Register · University Enrollment Portal</title>
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="stylesheet" href="assets/css/style.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head><body>
<div class="split">
  <div class="left">
    <div class="brand">
      <img class="logo-img" src="assets/img/logo.png" alt="School logo" width="44" height="44">
      <div><b>University Enrollment System</b><small>Student &amp; Staff Portal</small></div>
    </div>
    <div>
      <span class="eyebrow hide-sm">New Student</span>
      <h1>Create your student account.</h1>
      <div class="mu-dark hide-sm">Submit your details once. After Staff approval, you can log in and start enrolling.</div>
      <ul class="feat hide-sm">
        <li>Fill in your personal and academic info</li>
        <li>Receive your Student ID instantly</li>
        <li>Log in once your registration is approved</li>
      </ul>
    </div>
    <div class="mu-dark hide-sm">Already registered? <a href="index.php" style="color:#ffb26b">Log in here</a></div>
  </div>
  <div class="right"><div class="box wide">
  <?php if ($newId): ?>
    <span class="eyebrow">Registration</span>
    <h1 style="margin-top:6px">Registration submitted</h1>
    <div class="ok" style="margin-top:14px">Your registration was sent to Staff for approval.</div>
    <div class="success-id">
      <div class="mu">Your Student ID (pending)</div>
      <div class="num" style="color:var(--pr-dark)"><?= e($newId) ?></div>
    </div>
    <div class="mu">Keep this ID. You'll be able to log in once your registration is approved.</div>
    <a class="btn full" href="index.php">Return to Login</a>
  <?php else: ?>
    <div class="box-head">
      <span class="eyebrow">Student Registration</span>
      <h1>Create an account</h1>
      <div class="mu">All fields are required.</div>
    </div>
    <?php if ($error): ?><div class="err" role="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" id="regForm" novalidate>
      <?= csrf_field() ?>
      <div class="section-label">Personal Information</div>
      <div class="row">
        <div><label>Full Name</label>
  <input name="full_name" type="text" maxlength="100"
         pattern="[A-Za-zÀ-ÿ\s.'\-]+"
         title="Letters only. Spaces, periods, apostrophes and hyphens are allowed."
         oninput="this.value=this.value.replace(/[^\p{L}\s.'\-]/gu,'')"
         value="<?= e($_POST['full_name'] ?? '') ?>" required></div>
        <div><label>Birthday</label><input type="date" name="birthday" min="<?= date('Y-m-d', strtotime('-60 years')) ?>" max="<?= date('Y-m-d', strtotime('-14 years')) ?>" value="<?= e($_POST['birthday'] ?? '') ?>" required></div>
        <div><label>Gender</label>
          <select name="gender" required>
            <option value="">Select</option>
            <option <?= ($_POST['gender'] ?? '')=='Male'?'selected':'' ?>>Male</option>
            <option <?= ($_POST['gender'] ?? '')=='Female'?'selected':'' ?>>Female</option>
            <option <?= ($_POST['gender'] ?? '')=='Other'?'selected':'' ?>>Other</option>
          </select>
        </div>
        <div><label>Address</label><input name="address" maxlength="255" minlength="5" value="<?= e($_POST['address'] ?? '') ?>" required></div>
        <div><label>Contact Number</label>
  <input name="contact_number" type="tel" inputmode="numeric" maxlength="11" pattern="09[0-9]{9}"
         title="Enter an 11-digit number starting with 09 (e.g. 09123456789)"
         oninput="this.value=this.value.replace(/[^0-9]/g,'')"
         value="<?= e($_POST['contact_number'] ?? '') ?>" required></div>
        <div><label>Email</label><input type="email" name="email" maxlength="100" value="<?= e($_POST['email'] ?? '') ?>" required></div>
        </div>
      <div class="section-label">Academic Information</div>
      <div class="row">
        <div><label>Campus</label>
          <select name="campus" id="campusSel" required>
            <option value="">Select</option>
            <?php foreach (campuses() as $cp): ?>
              <option <?= ($_POST['campus'] ?? '') === $cp ? 'selected' : '' ?>><?= e($cp) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div><label>Course / Program</label>
          <select name="program" id="programSel" required>
            <option value="">Select campus first</option>
            <?php foreach (program_catalog() as $code => $p): ?>
              <option value="<?= e($code) ?>" data-campus="<?= e($p['campus']) ?>" <?= ($_POST['program'] ?? '') === $code ? 'selected' : '' ?>><?= e($p['name']) ?> (<?= e($code) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="section-label">Account Security</div>
      <div class="row">
        <div><label for="password">Password</label>
          <input id="password" type="password" name="password" data-pw minlength="8" maxlength="72" placeholder="At least 8 characters, letters and numbers" required>
          <div class="hint" id="pwHint">At least 8 characters with a letter and a number.</div></div>
        <div><label for="confirm_password">Confirm Password</label>
          <input id="confirm_password" type="password" name="confirm_password" data-pw maxlength="72" placeholder="Re-enter password" required>
          <div class="field-err" id="cfErr">Passwords do not match.</div></div>
      </div>
      <button class="full" type="submit">Register</button>
    </form>
    <div class="auth-foot mu">Already have an account? <a href="index.php">Back to Login</a></div>
  <?php endif; ?>
  </div></div>
</div>
<script src="assets/js/password.js"></script>
<script>
(function () {
  var f = document.getElementById('regForm'); if (!f) return;
  var $ = function (n) { return f.elements[n]; };

  // One rule per field: returns an error message, or '' if the value is fine.
  var rules = {
    full_name: function (v) {
      v = v.trim();
      if (!v) return 'Full name is required.';
      if (v.length < 2) return 'Full name must be at least 2 characters.';
      if (!/^[\p{L}][\p{L}\s.'\-]*$/u.test(v)) return 'Use letters, spaces, periods, apostrophes and hyphens only.';
      return '';
    },
    birthday: function (v) {
      if (!v) return 'Birthday is required.';
      var d = new Date(v + 'T00:00:00'), now = new Date(); now.setHours(0, 0, 0, 0);
      if (isNaN(d)) return 'Please enter a valid birthday.';
      if (d > now) return 'Birthday cannot be in the future.';
      var age = now.getFullYear() - d.getFullYear();
      if (now < new Date(now.getFullYear(), d.getMonth(), d.getDate())) age--;
      if (age < 14) return 'You must be at least 14 years old to register.';
      if (age > 60) return 'Please enter a valid birthday.';
      return '';
    },
    gender:  function (v) { return v ? '' : 'Please select your gender.'; },
    address: function (v) { v = v.trim(); return !v ? 'Address is required.' : (v.length < 5 ? 'Address is too short.' : ''); },
    contact_number: function (v) { return /^09[0-9]{9}$/.test(v) ? '' : 'Enter 11 digits starting with 09 (e.g. 09123456789).'; },
    email: function (v) {
      v = v.trim();
      if (!v) return 'Email is required.';
      return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Please enter a valid email address.';
    },
    program: function (v) { return v ? '' : 'Please select your course.'; },
    campus:  function (v) { return v ? '' : 'Please select your campus.'; },
    password: function (v) {
      if (v.length < 8) return 'Password must be at least 8 characters.';
      if (!/[A-Za-z]/.test(v) || !/[0-9]/.test(v)) return 'Password needs at least one letter and one number.';
      return '';
    },
    confirm_password: function (v) { return v === $('password').value ? '' : 'Passwords do not match.'; }
  };

  function errBox(el) {
    var box = el.parentNode.classList.contains('pw') ? el.parentNode.parentNode : el.parentNode;
    var m = box.querySelector('.field-err[data-auto]');
    if (!m) { m = document.createElement('div'); m.className = 'field-err'; m.setAttribute('data-auto', '1'); box.appendChild(m); }
    return m;
  }
  function check(name, show) {
    var el = $(name), msg = rules[name](el.value);
    if (show) { el.classList.toggle('invalid', !!msg); var m = errBox(el); m.textContent = msg; m.classList.toggle('show', !!msg); }
    return msg === '';
  }

  // Hide the static helper text once the live message takes over
  var hint = document.getElementById('pwHint'), oldCf = document.getElementById('cfErr');
  if (oldCf) oldCf.remove();

  Object.keys(rules).forEach(function (n) {
    var el = $(n);
    el.addEventListener('blur', function () { check(n, true); });
    el.addEventListener('input', function () {
      if (el.classList.contains('invalid')) check(n, true);
      if (n === 'password' && $('confirm_password').value) check('confirm_password', true);
    });
  });

  f.addEventListener('submit', function (ev) {
    var firstBad = null;
    Object.keys(rules).forEach(function (n) { if (!check(n, true) && !firstBad) firstBad = $(n); });
    if (firstBad) { ev.preventDefault(); firstBad.focus(); }
  });
})();
</script>
<script>
// The course list only shows programs offered at the chosen campus
(function () {
  var campusSel = document.getElementById('campusSel'), programSel = document.getElementById('programSel');
  if (!campusSel || !programSel) return;
  var all = Array.prototype.slice.call(programSel.querySelectorAll('option[data-campus]'));
  function sync() {
    var c = campusSel.value, keep = programSel.value;
    programSel.innerHTML = '';
    var first = document.createElement('option');
    first.value = ''; first.textContent = c ? 'Select course' : 'Select campus first';
    programSel.appendChild(first);
    all.forEach(function (o) { if (o.getAttribute('data-campus') === c) programSel.appendChild(o); });
    var ok = all.some(function (o) { return o.value === keep && o.getAttribute('data-campus') === c; });
    programSel.value = ok ? keep : '';
  }
  campusSel.addEventListener('change', sync);
  sync();
})();
</script>
</body></html>


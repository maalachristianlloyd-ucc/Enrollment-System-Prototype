<?php
// Shared helpers: CSRF, validation, and search + sort + pagination for tables.
// Included automatically by includes/auth.php.

/* ==========================================================
   CSRF protection (for every POST form)
   ========================================================== */
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field() {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}
// Call at the top of any POST handler. Stops the request if the token is wrong.
function csrf_check() {
    $ok = isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
    if (!$ok) {
        http_response_code(419);
        die('Your session expired or the request was invalid. Go back, refresh the page and try again.');
    }
}

/* ==========================================================
   Validation — every function returns an error string, or '' if valid
   ========================================================== */
function v_name($v, $label = 'Full name') {
    $v = trim($v);
    if ($v === '') return "$label is required.";
    if (mb_strlen($v) < 2) return "$label must be at least 2 characters.";
    if (mb_strlen($v) > 100) return "$label must be 100 characters or less.";
    if (!preg_match("/^[\p{L}][\p{L}\s.'\-]*$/u", $v)) return "$label may only contain letters, spaces, periods, apostrophes and hyphens.";
    return '';
}
function v_phone($v) {
    if (!preg_match('/^09[0-9]{9}$/', trim($v))) return 'Contact number must be 11 digits and start with 09 (e.g. 09123456789).';
    return '';
}
function v_email($v) {
    $v = trim($v);
    if ($v === '') return 'Email is required.';
    if (mb_strlen($v) > 100) return 'Email must be 100 characters or less.';
    if (!filter_var($v, FILTER_VALIDATE_EMAIL)) return 'Please enter a valid email address.';
    return '';
}
function v_address($v) {
    $v = trim($v);
    if ($v === '') return 'Address is required.';
    if (mb_strlen($v) < 5) return 'Address is too short.';
    if (mb_strlen($v) > 255) return 'Address must be 255 characters or less.';
    return '';
}
// Freshmen are expected to be roughly 14–60 years old; birthday can't be in the future.
function v_birthday($v) {
    $d = DateTime::createFromFormat('Y-m-d', $v);
    if (!$d || $d->format('Y-m-d') !== $v) return 'Please enter a valid birthday.';
    $now = new DateTime('today');
    if ($d > $now) return 'Birthday cannot be in the future.';
    $age = $d->diff($now)->y;
    if ($age < 14) return 'You must be at least 14 years old to register.';
    if ($age > 60) return 'Please enter a valid birthday.';
    return '';
}
function v_password($p, $min = 8) {
    if (strlen($p) < $min) return "Password must be at least $min characters.";
    if (strlen($p) > 72) return 'Password must be 72 characters or less.';
    if (!preg_match('/[A-Za-z]/', $p) || !preg_match('/[0-9]/', $p)) return 'Password must contain at least one letter and one number.';
    return '';
}
function v_username($v) {
    if (!preg_match('/^[A-Za-z0-9_.]{4,30}$/', trim($v))) return 'Username must be 4–30 characters: letters, numbers, underscore or period only.';
    return '';
}
function v_in($v, array $allowed, $label) {
    return in_array($v, $allowed, true) ? '' : "Please choose a valid $label.";
}
// Returns the first non-empty error from a list, or ''.
function first_error(array $errors) {
    foreach ($errors as $err) if ($err !== '') return $err;
    return '';
}

/* ==========================================================
   Search + Sort + Pagination
   ----------------------------------------------------------
   $cfg = [
     'select'   => 's.*, sec.name AS section_name',
     'from'     => 'students s LEFT JOIN sections sec ON s.section_id = sec.id',
     'where'    => ["s.status = 'approved'"],     // fixed conditions (no user input)
     'params'   => [], 'types' => '',               // bound values for the fixed conditions
     'search'   => ['s.full_name', 's.student_id'], // columns searched by ?q=
     'sortable' => ['id' => 's.student_id', 'name' => 's.full_name'],
     'default_sort' => 'name', 'default_dir' => 'asc',
     'per_page' => 10,
   ]
   ========================================================== */
function list_query($conn, array $cfg) {
    $where  = $cfg['where']  ?? [];
    $params = $cfg['params'] ?? [];
    $types  = $cfg['types']  ?? '';

    // --- search ---
    $q = trim($_GET['q'] ?? '');
    if (mb_strlen($q) > 100) $q = mb_substr($q, 0, 100);
    if ($q !== '' && !empty($cfg['search'])) {
        $like = '%' . addcslashes($q, '%_\\') . '%';
        $parts = [];
        foreach ($cfg['search'] as $col) { $parts[] = "$col LIKE ?"; $params[] = $like; $types .= 's'; }
        $where[] = '(' . implode(' OR ', $parts) . ')';
    }
    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    // --- sort (whitelisted — user input never reaches the SQL directly) ---
    $sortable = $cfg['sortable'] ?? [];
    $sort = $_GET['sort'] ?? ($cfg['default_sort'] ?? '');
    if (!isset($sortable[$sort])) $sort = $cfg['default_sort'] ?? array_key_first($sortable);
    $dir = strtolower($_GET['dir'] ?? ($cfg['default_dir'] ?? 'asc')) === 'desc' ? 'desc' : 'asc';
    $orderSql = $sortable ? 'ORDER BY ' . $sortable[$sort] . ' ' . strtoupper($dir) : '';

    // --- count ---
    $stmt = $conn->prepare("SELECT COUNT(*) c FROM {$cfg['from']} $whereSql");
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $total = (int)$stmt->get_result()->fetch_assoc()['c'];

    // --- page ---
    $allowedPer = [10, 25, 50];
    $perPage = (int)($_GET['per'] ?? ($cfg['per_page'] ?? 10));
    if (!in_array($perPage, $allowedPer, true)) $perPage = $cfg['per_page'] ?? 10;
    $pages = max(1, (int)ceil($total / $perPage));
    $page  = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
    $offset = ($page - 1) * $perPage;

    // --- rows ---
    $stmt = $conn->prepare("SELECT {$cfg['select']} FROM {$cfg['from']} $whereSql $orderSql LIMIT ? OFFSET ?");
    $t2 = $types . 'ii'; $p2 = array_merge($params, [$perPage, $offset]);
    $stmt->bind_param($t2, ...$p2);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    return compact('rows', 'total', 'page', 'pages', 'perPage', 'q', 'sort', 'dir', 'offset');
}

// Builds a URL that keeps the current search/sort/page but overrides some values.
function list_url(array $override = []) {
    $keep = array_filter($_GET, 'is_scalar');   // keeps search, sort, page and every filter
    $merged = array_merge($keep, $override);
    foreach ($merged as $k => $v) if ($v === null || $v === '') unset($merged[$k]);
    return '?' . http_build_query($merged);
}

// Search box + rows-per-page selector.
function list_toolbar(array $lt, $placeholder = 'Search…', array $filters = []) {
    $hidden = '';
    foreach (['sort', 'dir', 'view', 'type'] as $k) {
        if (isset($_GET[$k])) $hidden .= '<input type="hidden" name="' . e($k) . '" value="' . e($_GET[$k]) . '">';
    }
    $html  = '<form method="GET" class="toolbar">' . $hidden;
    $html .= '<div class="search"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>';
    $html .= '<input type="search" name="q" maxlength="100" placeholder="' . e($placeholder) . '" value="' . e($lt['q']) . '" aria-label="Search"></div>';
    // Optional dropdown filters: ['course' => ['All courses', ['BSIT' => 'BSIT', ...]]]
    foreach ($filters as $name => [$allLabel, $opts]) {
        $cur = $_GET[$name] ?? '';
        $html .= '<select name="' . e($name) . '" class="filter" aria-label="' . e($allLabel) . '" onchange="this.form.submit()"><option value="">' . e($allLabel) . '</option>';
        foreach ($opts as $val => $lbl) $html .= '<option value="' . e($val) . '"' . ($cur === (string)$val ? ' selected' : '') . '>' . e($lbl) . '</option>';
        $html .= '</select>';
    }
    $html .= '<button type="submit">Search</button>';
    if ($lt['q'] !== '' || !empty(array_filter(array_map(fn($n) => $_GET[$n] ?? '', array_keys($filters))))) $html .= '<a class="btn sec" href="' . e(list_url(['q' => null, 'page' => null] + array_fill_keys(array_keys($filters), null))) . '">Clear</a>';
    $html .= '<label class="per">Show <select name="per" onchange="this.form.submit()">';
    foreach ([10, 25, 50] as $n) $html .= '<option value="' . $n . '"' . ($lt['perPage'] === $n ? ' selected' : '') . '>' . $n . '</option>';
    $html .= '</select> per page</label></form>';
    return $html;
}

// Clickable, sortable <th>.
function sort_th(array $lt, $key, $label) {
    $active = $lt['sort'] === $key;
    $next = ($active && $lt['dir'] === 'asc') ? 'desc' : 'asc';
    $arrow = $active ? ($lt['dir'] === 'asc' ? ' ▲' : ' ▼') : ' <span style="opacity:.35">↕</span>';
    return '<th class="sortable' . ($active ? ' sorted' : '') . '"><a href="' . e(list_url(['sort' => $key, 'dir' => $next, 'page' => 1])) . '">' . e($label) . $arrow . '</a></th>';
}

// "Showing 1–10 of 42" + Prev / numbered pages / Next.
function list_pagination(array $lt) {
    if ($lt['total'] === 0) return '';
    $from = $lt['offset'] + 1;
    $to = min($lt['offset'] + $lt['perPage'], $lt['total']);
    $html  = '<div class="pager"><span class="mu">Showing ' . $from . '–' . $to . ' of ' . $lt['total'] . '</span>';
    if ($lt['pages'] > 1) {
        $html .= '<nav aria-label="Pagination">';
        $p = $lt['page']; $last = $lt['pages'];
        $html .= $p > 1 ? '<a href="' . e(list_url(['page' => $p - 1])) . '">‹ Prev</a>' : '<span class="off">‹ Prev</span>';
        $shown = array_unique(array_filter([1, $p - 2, $p - 1, $p, $p + 1, $p + 2, $last], fn($n) => $n >= 1 && $n <= $last));
        sort($shown); $prev = 0;
        foreach ($shown as $n) {
            if ($n - $prev > 1) $html .= '<span class="gap">…</span>';
            $html .= $n === $p ? '<span class="cur" aria-current="page">' . $n . '</span>' : '<a href="' . e(list_url(['page' => $n])) . '">' . $n . '</a>';
            $prev = $n;
        }
        $html .= $p < $last ? '<a href="' . e(list_url(['page' => $p + 1])) . '">Next ›</a>' : '<span class="off">Next ›</span>';
        $html .= '</nav>';
    }
    return $html . '</div>';
}

// Empty-state row for tables.
function empty_row($cols, $q = '') {
    $msg = $q !== '' ? 'No results found for “' . e($q) . '”.' : 'Nothing to show yet.';
    return '<tr><td colspan="' . (int)$cols . '" class="mu" style="text-align:center;padding:26px">' . $msg . '</td></tr>';
}

/* ==========================================================
   Flash messages + redirect-after-POST (stops "resubmit form?" on refresh)
   ========================================================== */
function flash_set($type, $msg) { $_SESSION['flash'] = [$type, $msg]; }
function flash_show() {
    if (empty($_SESSION['flash'])) return '';
    [$type, $msg] = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $type === 'err'
        ? '<div class="err" role="alert" style="margin:0 0 12px">' . e($msg) . '</div>'
        : '<div class="ok" style="margin-bottom:12px">✔ ' . e($msg) . '</div>';
}
function redirect_back() {
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}

// Shared <head> for logged-in pages.
function page_head($title) {
    return '<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>' . e($title) . '</title><link rel="icon" type="image/png" href="' . BASE_PATH . '/assets/img/favicon.png"><link rel="stylesheet" href="' . BASE_PATH . '/assets/css/style.css?v=' . (int)@filemtime(__DIR__ . '/../assets/css/style.css') . '"></head>';
}

// Class days a schedule may use, in the order they are written (MWF, TTh, Sat ...)
const SCHEDULE_DAYS = ['M' => 'Monday', 'T' => 'Tuesday', 'W' => 'Wednesday', 'Th' => 'Thursday', 'F' => 'Friday', 'Sat' => 'Saturday', 'Sun' => 'Sunday'];

// Schedule like "MWF 8:00-9:00" or "TTh 10:00-11:30".
// Days must be real day codes, class hours 7:00-21:00, at least 30 minutes long, end after start.
function v_schedule($v) {
    $v = trim($v);
    if (!preg_match('/^([A-Za-z]{1,12})\s+(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/', $v, $m))
        return 'Schedule must look like "MWF 8:00-9:00" (days, then start-end time).';
    if (!preg_match('/^(?:Th|Sat|Sun|M|T|W|F)+$/i', $m[1]))
        return 'Schedule days must use M, T, W, Th, F, Sat or Sun (e.g. MWF, TTh, Sat).';
    [$h1, $m1, $h2, $m2] = [(int)$m[2], (int)$m[3], (int)$m[4], (int)$m[5]];
    if ($h1 > 23 || $h2 > 23 || $m1 > 59 || $m2 > 59) return 'Schedule contains an invalid time.';
    $start = $h1 * 60 + $m1; $end = $h2 * 60 + $m2;
    if ($end <= $start) return 'Schedule end time must be after the start time.';
    if ($start < 7 * 60 || $end > 21 * 60) return 'Class hours must be between 7:00 AM and 9:00 PM (7:00-21:00).';
    if ($end - $start < 30) return 'A class must be at least 30 minutes long.';
    return '';
}

// Builds "MWF 8:00-9:00" from checked days + two <input type="time"> values. Returns [schedule, error].
function build_schedule($days, $start, $end) {
    $days = array_values(array_intersect(array_keys(SCHEDULE_DAYS), array_map('strval', (array)$days)));   // junk is ignored, order is fixed
    if (!$days) return ['', 'Select at least one class day.'];
    foreach ([$start, $end] as $t) {
        if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string)$t)) return ['', 'Please choose a valid start and end time.'];
    }
    $fmt = fn($t) => (int)substr($t, 0, 2) . substr($t, 2);   // 08:00 -> 8:00
    $s = implode('', $days) . ' ' . $fmt($start) . '-' . $fmt($end);
    return [$s, v_schedule($s)];
}

// A valid past date (no age limit) — used where we only need to match a stored birthday.
function v_birthday_any($v) {
    $d = DateTime::createFromFormat('Y-m-d', $v);
    if (!$d || $d->format('Y-m-d') !== $v) return 'Please enter a valid birthday.';
    if ($d > new DateTime('today')) return 'Birthday cannot be in the future.';
    return '';
}

// Returns $_GET[$name] only if it is one of the allowed values (so a filter can never inject anything).
function allowed_get($name, array $allowed) {
    $v = $_GET[$name] ?? '';
    return (is_string($v) && in_array($v, $allowed, true)) ? $v : '';
}


/* ==========================================================
   Campuses and programs  (the ONE place to edit them)
   'group' lets a subject be shared by a few programs without being for everyone:
       subjects.program = 'BSIT'  -> only BSIT
       subjects.program = 'CSD'   -> all CSD programs (BSIT, BSCS, BSIS, BSEMC)
       subjects.program = 'ALL'   -> every program on every campus (general subjects)
   ========================================================== */
function campuses() { return ['Congressional', 'Camarin']; }

function program_catalog() {
    return [
        'BSIT'   => ['name' => 'Bachelor of Science in Information Technology',                 'campus' => 'Congressional', 'group' => 'CSD'],
        'BSCS'   => ['name' => 'Bachelor of Science in Computer Science',                       'campus' => 'Congressional', 'group' => 'CSD'],
        'BSIS'   => ['name' => 'Bachelor of Science in Information Systems',                    'campus' => 'Congressional', 'group' => 'CSD'],
        'BSEMC'  => ['name' => 'Bachelor of Science in Entertainment and Multimedia Computing', 'campus' => 'Congressional', 'group' => 'CSD'],
        'BSCRIM' => ['name' => 'Bachelor of Science in Criminology',                            'campus' => 'Camarin',       'group' => ''],
        'BSA'    => ['name' => 'Bachelor of Science in Accountancy',                            'campus' => 'Camarin',       'group' => ''],
    ];
}
function program_codes($campus = null) {
    $out = [];
    foreach (program_catalog() as $code => $p) if ($campus === null || $p['campus'] === $campus) $out[] = $code;
    return $out;
}
// The subject "program" values a student of this program is allowed to see: own program, shared group, and ALL.
function program_group($code) { return program_catalog()[$code]['group'] ?? ''; }
function program_label($v) {
    if ($v === 'ALL') return 'All Courses (every program)';
    if ($v === 'CSD') return 'CSD programs only (BSIT, BSCS, BSIS, BSEMC)';
    return $v;
}

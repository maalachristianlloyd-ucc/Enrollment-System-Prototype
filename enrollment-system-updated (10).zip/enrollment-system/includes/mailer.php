<?php
// Sends email through SMTP (Gmail) using PHPMailer. Settings are in config/mail.php.
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;

require_once __DIR__ . '/../config/mail.php';
require_once __DIR__ . '/PHPMailer/Exception.php';
require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';

function mail_is_configured() {
    return MAIL_ENABLED
        && MAIL_USERNAME !== '' && MAIL_USERNAME !== 'yourschool@gmail.com'
        && MAIL_PASSWORD !== '' && MAIL_PASSWORD !== 'xxxx xxxx xxxx xxxx'
        && (IS_LOCAL || stripos(BASE_URL, 'localhost') === false);   // online but BASE_URL still says localhost = wrong links
}

// Returns [true, ''] on success or [false, 'reason'] on failure.
function send_mail($toEmail, $toName, $subject, $html, $text) {
    if (!mail_is_configured()) return [false, 'Email is not set up yet. Fill in config/mail.php and set MAIL_ENABLED to true.'];
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USERNAME;
        $mail->Password   = str_replace(' ', '', MAIL_PASSWORD);   // Google shows the code with spaces
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;
        $mail->Timeout    = 12;
        $mail->CharSet    = 'UTF-8';
        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $html;
        $mail->AltBody = $text;
        $mail->send();
        return [true, ''];
    } catch (MailException $ex) {
        error_log('Mail error: ' . $mail->ErrorInfo);
        return [false, $mail->ErrorInfo ?: $ex->getMessage()];
    }
}

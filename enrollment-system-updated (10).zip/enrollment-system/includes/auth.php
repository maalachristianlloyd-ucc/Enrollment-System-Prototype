<?php
// ---- Where is the site? -------------------------------------------------
// BASE_PATH is the folder the site lives in, worked out automatically:
//   http://localhost/enrollment-system/  ->  '/enrollment-system'
//   http://yourname.rf.gd/               ->  ''   (files uploaded straight into htdocs)
if (!defined('BASE_PATH')) {
    $docRoot  = !empty($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
    $siteRoot = realpath(__DIR__ . '/..');
    if ($docRoot && $siteRoot) {
        $d = rtrim(str_replace('\\', '/', $docRoot), '/');
        $s = str_replace('\\', '/', $siteRoot);
        define('BASE_PATH', stripos($s, $d) === 0 ? rtrim(substr($s, strlen($d)), '/') : '/enrollment-system');
    } else {
        define('BASE_PATH', '/enrollment-system');
    }
}
// Running on your own PC (XAMPP) or online?
define('IS_LOCAL', DIRECTORY_SEPARATOR === '\\' || in_array($_SERVER['SERVER_NAME'] ?? 'localhost', ['localhost', '127.0.0.1', '::1'], true));
if (!IS_LOCAL) { ini_set('display_errors', '0'); ini_set('log_errors', '1'); }   // never show PHP errors to the public

// Harden the session cookie before starting the session.
if (session_status() === PHP_SESSION_NONE) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => $https]);
    session_start();
}

// Where each role logs in. Students use index.php; Staff/Admin/Superadmin use staff-login.php.
function login_url_for($role) {
    return $role === 'student'
        ? BASE_PATH . '/index.php'
        : BASE_PATH . '/staff-login.php';
}

function dashboard_url_for($role) {
    return BASE_PATH . "/$role/dashboard.php";
}

// Call at the top of any page that requires a specific role.
// Example: require_role('student');
function require_role($role) {
    if (!isset($_SESSION['role'])) {
        header("Location: " . login_url_for($role));
        exit;
    }
    if ($_SESSION['role'] !== $role) {
        // Logged in, but on the wrong portal -> send them back to their own dashboard.
        header("Location: " . dashboard_url_for($_SESSION['role']));
        exit;
    }
}

function current_user_name() {
    return $_SESSION['full_name'] ?? '';
}

function e($str) {
    // Escape output to prevent XSS
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// Saves a line in the activity log (shown to the Superadmin).
function log_activity($conn, $action) {
    $role = $_SESSION['role'] ?? 'guest';
    $name = $_SESSION['full_name'] ?? 'Unknown';
    $stmt = $conn->prepare("INSERT INTO activity_logs (actor_role, actor_name, action) VALUES (?,?,?)");
    $stmt->bind_param("sss", $role, $name, $action);
    $stmt->execute();
}

// Simple brute-force protection: 5 failed logins -> locked for LOGIN_LOCK_SECONDS (per session).
// Change the number below to adjust the lock time (120 = 2 minutes).
define('LOGIN_LOCK_SECONDS', 120);
function login_locked() {
    return ($_SESSION['login_fail'] ?? 0) >= 5 && (time() - ($_SESSION['login_fail_at'] ?? 0)) < LOGIN_LOCK_SECONDS;
}
function login_failed() {
    if ((time() - ($_SESSION['login_fail_at'] ?? 0)) >= LOGIN_LOCK_SECONDS) $_SESSION['login_fail'] = 0;
    $_SESSION['login_fail'] = ($_SESSION['login_fail'] ?? 0) + 1;
    $_SESSION['login_fail_at'] = time();
}
function login_reset() { unset($_SESSION['login_fail'], $_SESSION['login_fail_at']); }

// Same idea for the Forgot Password form (separate counter, so it can't be used to guess details forever).
function reset_locked() {
    return ($_SESSION['reset_fail'] ?? 0) >= 5 && (time() - ($_SESSION['reset_fail_at'] ?? 0)) < LOGIN_LOCK_SECONDS;
}
function reset_failed() {
    if ((time() - ($_SESSION['reset_fail_at'] ?? 0)) >= LOGIN_LOCK_SECONDS) $_SESSION['reset_fail'] = 0;
    $_SESSION['reset_fail'] = ($_SESSION['reset_fail'] ?? 0) + 1;
    $_SESSION['reset_fail_at'] = time();
}

require_once __DIR__ . '/helpers.php';

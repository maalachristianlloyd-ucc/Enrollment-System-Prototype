<?php
// Expects $role, $active, and $conn to be set by the including page.
$nav = [
    'student' => [
        'Dashboard' => BASE_PATH . '/student/dashboard.php',
        'My Profile' => BASE_PATH . '/student/profile.php',
        'Subject List' => BASE_PATH . '/student/subjects.php',
        'Enrollment' => BASE_PATH . '/student/enrollment.php',
        'My Schedule' => BASE_PATH . '/student/schedule.php',
    ],
    'staff' => [
        'Dashboard' => BASE_PATH . '/staff/dashboard.php',
        'Pending Registrations' => BASE_PATH . '/staff/pending.php',
        'Search Students' => BASE_PATH . '/staff/search.php',
    ],
    'admin' => [
        'Dashboard' => BASE_PATH . '/admin/dashboard.php',
        'Enrollment Requests' => BASE_PATH . '/admin/requests.php',
        'Student Records' => BASE_PATH . '/admin/students.php',
        'Subjects' => BASE_PATH . '/admin/subjects.php',
        'Sections' => BASE_PATH . '/admin/sections.php',
        'Reports' => BASE_PATH . '/admin/reports.php',
    ],
    'superadmin' => [
        'Dashboard' => BASE_PATH . '/superadmin/dashboard.php',
        'Manage Accounts' => BASE_PATH . '/superadmin/accounts.php',
        'Activity Log' => BASE_PATH . '/superadmin/logs.php',
    ],
];
$labels = ['student' => 'Student Portal', 'staff' => 'Staff Portal', 'admin' => 'Admin Panel', 'superadmin' => 'Superadmin Panel'];

// Live badges: pending registrations (staff) and pending enrollment requests (admin)
$__reg = 0; $__enr = 0; $__watch = [];
if (in_array($role, ['staff', 'admin'], true) && isset($conn)) {
    $__reg = (int)$conn->query("SELECT COUNT(*) c FROM students WHERE status='pending'")->fetch_assoc()['c'];
    $__enr = (int)$conn->query("SELECT COUNT(*) c FROM enrollments WHERE status='pending'")->fetch_assoc()['c'];
    // pages that should refresh themselves when something new arrives
    if ($role === 'staff' && in_array($active, ['Dashboard', 'Pending Registrations'], true)) $__watch = ['reg'];
    if ($role === 'admin' && in_array($active, ['Dashboard', 'Enrollment Requests'], true))   $__watch = ['enr'];
}
?>
<?php
$__name = current_user_name();
$__parts = preg_split('/\s+/', trim($__name));
$__ini = strtoupper(substr($__parts[0] ?? '', 0, 1) . substr(end($__parts) ?: '', 0, 1));
?>
<div class="side">
  <div class="brand">
    <img class="logo-img" src="<?= BASE_PATH ?>/assets/img/logo.png" alt="School logo" width="44" height="44">
    <div><b>Enrollment System</b><small><?= e($labels[$role]) ?></small></div>
  </div>
  <div class="nav-label">Menu</div>
  <?php foreach ($nav[$role] as $label => $url): ?>
    <a class="<?= $active === $label ? 'on' : '' ?>" href="<?= $url ?>">
      <span><?= e($label) ?></span>
      <?php if ($role === 'staff' && $label === 'Pending Registrations'): ?>
        <span class="badge-count" data-live-badge="reg" <?= $__reg > 0 ? '' : 'hidden' ?>><?= $__reg ?></span>
      <?php elseif ($role === 'admin' && $label === 'Enrollment Requests'): ?>
        <span class="badge-count" data-live-badge="enr" <?= $__enr > 0 ? '' : 'hidden' ?>><?= $__enr ?></span>
      <?php endif; ?>
    </a>
  <?php endforeach; ?>
  <div class="side-foot">
    <div class="user">
      <div class="avatar"><?= e($__ini ?: '?') ?></div>
      <div><b><?= e($__name) ?></b><small><?= e(ucfirst($role)) ?></small></div>
    </div>
    <a class="logout" href="<?= BASE_PATH ?>/logout.php" data-confirm="Do you want to log out of your account?" data-confirm-title="Log out" data-confirm-btn="Log out">Log out</a>
  </div>
</div>
<script src="<?= BASE_PATH ?>/assets/js/modal.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/modal.js') ?>"></script>
<?php if (in_array($role, ['staff', 'admin'], true)): ?>
<script>window.__LIVE = <?= json_encode(['url' => BASE_PATH . '/api/live.php', 'reg' => $__reg, 'enr' => $__enr, 'watch' => $__watch]) ?>;</script>
<script src="<?= BASE_PATH ?>/assets/js/live.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/live.js') ?>"></script>
<?php endif; ?>

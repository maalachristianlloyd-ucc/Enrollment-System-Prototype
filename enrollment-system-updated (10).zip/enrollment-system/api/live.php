<?php
// Tiny JSON endpoint used by the Staff/Admin pages to update the pending counts live.
// Only logged-in staff / admin / superadmin can read it. It returns numbers only.
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!in_array($_SESSION['role'] ?? '', ['staff', 'admin', 'superadmin'], true)) {
    http_response_code(401);
    echo '{"error":"not logged in"}';
    exit;
}
session_write_close();   // don't hold the session lock while polling

$reg = (int)$conn->query("SELECT COUNT(*) c FROM students WHERE status = 'pending'")->fetch_assoc()['c'];
$enr = (int)$conn->query("SELECT COUNT(*) c FROM enrollments WHERE status = 'pending'")->fetch_assoc()['c'];
echo json_encode(['reg' => $reg, 'enr' => $enr]);

// Live updates for Staff / Admin: checks every few seconds for new pending registrations / enrollment requests.
// New item -> the sidebar badge updates, and the page reloads itself (unless you are typing or a popup is open).
(function () {
  'use strict';
  var L = window.__LIVE;
  if (!L || !window.fetch) return;
  var busy = false, timer = null, toastEl = null;

  function badge(key, n) {
    document.querySelectorAll('[data-live-badge="' + key + '"]').forEach(function (b) { b.textContent = n; b.hidden = !(n > 0); });
  }
  function toast(msg, withRefresh) {
    if (!toastEl) { toastEl = document.createElement('div'); toastEl.className = 'toast'; toastEl.setAttribute('role', 'status'); document.body.appendChild(toastEl); }
    toastEl.innerHTML = '';
    var s = document.createElement('span'); s.textContent = msg; toastEl.appendChild(s);
    if (withRefresh) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = 'Refresh now';
      b.onclick = function () { location.reload(); };
      toastEl.appendChild(b);
    }
    toastEl.hidden = false;
  }
  function safeToReload() {
    if (document.querySelector('dialog[open]')) return false;                       // a popup is open
    var a = document.activeElement;
    return !(a && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName));                      // someone is typing / choosing
  }
  function poll() {
    if (document.hidden || busy) return;
    busy = true;
    fetch(L.url, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw r.status; return r.json(); })
      .then(function (d) {
        busy = false;
        var changed = [];
        ['reg', 'enr'].forEach(function (k) {
          if (typeof d[k] === 'number' && d[k] !== L[k]) { changed.push(k); L[k] = d[k]; badge(k, d[k]); }
        });
        var watched = changed.filter(function (k) { return (L.watch || []).indexOf(k) > -1; });
        if (!watched.length) return;
        if (safeToReload()) { toast('New activity received. Updating…'); setTimeout(function () { location.reload(); }, 900); }
        else { toast('New activity received.', true); }
      })
      .catch(function (err) { busy = false; if (err === 401) clearInterval(timer); });   // logged out -> stop checking
  }
  timer = setInterval(poll, 5000);
})();

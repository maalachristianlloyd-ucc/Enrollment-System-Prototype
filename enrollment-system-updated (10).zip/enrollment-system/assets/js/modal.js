// Confirmation modals + "Add" form modals (uses the built-in <dialog> element).
//
//   <form data-confirm="Delete this?" data-confirm-title="Delete" data-confirm-btn="Delete" data-confirm-style="danger">
//   <a href="..." data-confirm="Log out?">
//   <button data-open-modal="addModal">  opens  <dialog id="addModal" class="modal form-modal">
//   <button data-close-modal>            closes the dialog it is inside
//   <dialog data-open-on-load>           opens automatically (used to re-show a form that had errors)
(function () {
  'use strict';
  var dlg = null;

  function build() {
    if (dlg) return dlg;
    dlg = document.createElement('dialog');
    dlg.className = 'modal confirm-modal';
    dlg.setAttribute('aria-labelledby', 'cm-title');
    dlg.innerHTML =
      '<div class="modal-body"><div class="modal-icon" aria-hidden="true"></div>' +
      '<h3 class="modal-title" id="cm-title"></h3><p class="modal-msg"></p></div>' +
      '<div class="modal-actions"><button type="button" class="sec" data-act="cancel">Cancel</button>' +
      '<button type="button" data-act="ok">Confirm</button></div>';
    document.body.appendChild(dlg);
    return dlg;
  }

  function ask(opts, onOk, onCancel) {
    var d = build();
    var danger = opts.style === 'danger';
    var icon = d.querySelector('.modal-icon');
    var ok = d.querySelector('[data-act=ok]'), cancel = d.querySelector('[data-act=cancel]');
    d.querySelector('.modal-title').textContent = opts.title || 'Are you sure?';
    d.querySelector('.modal-msg').textContent = opts.message || '';
    icon.className = 'modal-icon ' + (danger ? 'danger' : 'info');
    icon.textContent = danger ? '!' : '?';
    ok.textContent = opts.okText || 'Confirm';
    ok.className = danger ? 'danger' : '';

    var done = false;
    function finish(yes) {
      if (done) return;
      done = true;
      ok.onclick = cancel.onclick = d.onclick = d.oncancel = null;
      d.close();
      if (yes) { if (onOk) onOk(); } else if (onCancel) { onCancel(); }
    }
    ok.onclick = function () { finish(true); };
    cancel.onclick = function () { finish(false); };
    d.oncancel = function (e) { e.preventDefault(); finish(false); };          // Esc key
    d.onclick = function (e) { if (e.target === d) finish(false); };           // click outside
    d.showModal();
    (danger ? cancel : ok).focus();                                            // dangerous actions: Cancel is the default
  }

  // "Add subject {code} for {program}?"  ->  fills {field} with what the user typed in that form
  function fill(tpl, f) {
    return (tpl || '').replace(/\{(\w+)\}/g, function (m, n) {
      var el = f.elements[n];
      if (!el) return '';
      if (el.tagName === 'SELECT') return el.options[el.selectedIndex] ? el.options[el.selectedIndex].text : '';
      return (el.value || '').trim();
    });
  }

  // Forms with data-confirm: ask first, then submit for real.
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!f || !f.hasAttribute || !f.hasAttribute('data-confirm')) return;
    if (f.getAttribute('data-confirmed') === '1') { f.removeAttribute('data-confirmed'); return; }
    // data-validate="fnName": run the page's own checks first, so the popup only appears for a valid form
    var vf = f.getAttribute('data-validate');
    if (vf && typeof window[vf] === 'function' && window[vf](f) === false) { e.preventDefault(); return; }
    e.preventDefault();
    var btn = e.submitter || null;
    ask({
      title: f.getAttribute('data-confirm-title'),
      message: fill(f.getAttribute('data-confirm'), f),
      okText: f.getAttribute('data-confirm-btn'),
      style: f.getAttribute('data-confirm-style')
    }, function () {
      f.setAttribute('data-confirmed', '1');
      if (f.requestSubmit) f.requestSubmit(btn); else f.submit();
    }, function () {
      if (f.hasAttribute('data-reset-on-cancel')) f.reset();                   // put a changed dropdown back
    });
  }, true);

  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest) return;

    var a = t.closest('a[data-confirm]');
    if (a) {
      e.preventDefault();
      ask({ title: a.getAttribute('data-confirm-title'), message: a.getAttribute('data-confirm'),
            okText: a.getAttribute('data-confirm-btn'), style: a.getAttribute('data-confirm-style') },
          function () { window.location.href = a.href; });
      return;
    }
    var opener = t.closest('[data-open-modal]');
    if (opener) {
      var m = document.getElementById(opener.getAttribute('data-open-modal'));
      if (m && m.showModal) {
        m.showModal();
        var first = m.querySelector('input:not([type=hidden]):not([type=checkbox]),select,textarea');
        if (first) first.focus();
      }
      return;
    }
    var closer = t.closest('[data-close-modal]');
    if (closer) { var own = closer.closest('dialog'); if (own) own.close(); return; }

    if (t.tagName === 'DIALOG' && t.classList.contains('form-modal')) t.close();   // click on the dark backdrop
  });

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('dialog[data-open-on-load]').forEach(function (d) { if (d.showModal) d.showModal(); });
  });
})();

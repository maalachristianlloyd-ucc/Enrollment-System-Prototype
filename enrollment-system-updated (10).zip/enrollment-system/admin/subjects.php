<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('admin');
$role = 'admin'; $active = 'Subjects';
$programs = array_merge(['ALL', 'CSD'], program_codes());
$old = ['code' => '', 'name' => '', 'units' => '', 'program' => 'ALL', 'days' => [], 'start_time' => '', 'end_time' => ''];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $old = [
            'code'       => strtoupper(trim($_POST['code'] ?? '')),
            'name'       => preg_replace('/\s+/', ' ', trim($_POST['name'] ?? '')),
            'units'      => trim($_POST['units'] ?? ''),
            'program'    => $_POST['program'] ?? '',
            'days'       => array_map('strval', (array)($_POST['days'] ?? [])),
            'start_time' => trim($_POST['start_time'] ?? ''),
            'end_time'   => trim($_POST['end_time'] ?? ''),
        ];
        // The schedule is BUILT from the checked days + two times, so it can never contain typed junk
        [$schedule, $schedErr] = build_schedule($old['days'], $old['start_time'], $old['end_time']);
        $letters = preg_match_all('/\p{L}/u', $old['name']);

        $error = first_error([
            preg_match('/^[A-Z]{2,6}[0-9]{2,4}$/', $old['code']) ? '' : 'Subject code must be 2–6 letters followed by 2–4 numbers, with no spaces (e.g. IT101, MATH102).',
            (mb_strlen($old['name']) >= 3 && mb_strlen($old['name']) <= 100) ? '' : 'Subject name must be 3–100 characters.',
            preg_match("/^\p{L}[\p{L}0-9 .,'&()\-]*$/u", $old['name']) ? '' : 'Subject name must start with a letter and use only letters, numbers and . , \' & ( ) -',
            ($letters >= 3) ? '' : 'Subject name must contain at least 3 letters.',
            in_array($old['units'], ['1', '2', '3', '4', '5', '6'], true) ? '' : 'Please choose the units (1 to 6).',
            $schedErr,
            v_in($old['program'], $programs, 'course'),
        ]);

        if (!$error) {
            $dup = $conn->prepare("SELECT id FROM subjects WHERE code = ?");
            $dup->bind_param("s", $old['code']); $dup->execute();
            if ($dup->get_result()->fetch_assoc()) $error = 'That subject code already exists.';
        }
        if (!$error) {
            $dupName = $conn->prepare("SELECT id FROM subjects WHERE LOWER(name) = LOWER(?) AND program = ?");
            $dupName->bind_param("ss", $old['name'], $old['program']); $dupName->execute();
            if ($dupName->get_result()->fetch_assoc()) $error = 'A subject with that name already exists for this course.';
        }
        if (!$error) {
            $units = (int)$old['units'];
            $stmt = $conn->prepare("INSERT INTO subjects (code, name, units, schedule, program) VALUES (?,?,?,?,?)");
            $stmt->bind_param("ssiss", $old['code'], $old['name'], $units, $schedule, $old['program']);
            $stmt->execute();
            log_activity($conn, "Added subject {$old['code']}");
            flash_set('ok', "Subject {$old['code']} added.");
            redirect_back();
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        // Don't delete subjects students are already enrolled in
        $used = $conn->prepare("SELECT COUNT(*) c FROM enrollment_items WHERE subject_id = ?");
        $used->bind_param("i", $id); $used->execute();
        if ($used->get_result()->fetch_assoc()['c'] > 0) {
            flash_set('err', 'This subject is part of existing enrollments, so it cannot be removed.');
        } else {
            $stmt = $conn->prepare("DELETE FROM subjects WHERE id = ?");
            $stmt->bind_param("i", $id); $stmt->execute();
            log_activity($conn, "Deleted subject #$id");
            flash_set('ok', 'Subject removed.');
        }
        redirect_back();
    }
}

// Course dropdown filter (e.g. BSIT shows only BSIT subjects)
$courseFilter = $_GET['course'] ?? '';
if (!in_array($courseFilter, $programs, true)) $courseFilter = '';
$lt = list_query($conn, [
    'select'   => '*',
    'from'     => 'subjects',
    'where'    => $courseFilter !== '' ? ['program = ?'] : [],
    'params'   => $courseFilter !== '' ? [$courseFilter] : [],
    'types'    => $courseFilter !== '' ? 's' : '',
    'search'   => ['code', 'name', 'schedule', 'program'],
    'sortable' => ['code' => 'code', 'name' => 'name', 'units' => 'units', 'schedule' => 'schedule', 'program' => 'program'],
    'default_sort' => 'code',
]);
echo page_head('Subjects');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Subjects</h1><span class="badge">Admin Panel</span></div>
  <?= flash_show() ?>

  <div class="page-actions"><button type="button" data-open-modal="addModal">+ Add Subject</button></div>
  <dialog class="modal form-modal" id="addModal" <?= $error ? 'data-open-on-load' : '' ?>>
    <div class="modal-head"><h3>Add Subject</h3><button type="button" class="x" data-close-modal aria-label="Close">&times;</button></div>
    <div class="modal-form">
    <?php if ($error): ?><div class="err" role="alert" style="margin:0 0 10px"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" id="subjForm" data-validate="validateSubjectForm"
          data-confirm="Add subject {code} – {name} ({units} units, {schedule_preview}) for {program}?" data-confirm-title="Add subject" data-confirm-btn="Add subject">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <div class="row">
        <div><label>Code</label><input name="code" maxlength="10" pattern="[A-Za-z]{2,6}[0-9]{2,4}" title="2–6 letters then 2–4 numbers, e.g. IT101" placeholder="e.g. IT101" value="<?= e($old['code']) ?>" required></div>
        <div><label>Name</label><input name="name" maxlength="100" minlength="3" placeholder="e.g. Intro to Computing" value="<?= e($old['name']) ?>" required></div>
        <div><label>Units</label>
          <select name="units" required>
            <option value="">Select</option>
            <?php for ($u = 1; $u <= 6; $u++): ?><option value="<?= $u ?>" <?= $old['units'] === (string)$u ? 'selected' : '' ?>><?= $u ?></option><?php endfor; ?>
          </select>
        </div>
        <div><label>Course</label>
          <select name="program" required>
            <?php foreach ($programs as $p): ?>
              <option value="<?= e($p) ?>" <?= $old['program'] === $p ? 'selected' : '' ?>><?= e(program_label($p)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="full-col">
          <label>Class days</label>
          <div class="chips">
            <?php foreach (SCHEDULE_DAYS as $code => $label): ?>
              <label title="<?= e($label) ?>"><input type="checkbox" name="days[]" value="<?= e($code) ?>" <?= in_array($code, $old['days'], true) ? 'checked' : '' ?>><span><?= e($code) ?></span></label>
            <?php endforeach; ?>
          </div>
        </div>
        <div><label>Start time</label><input type="time" name="start_time" min="07:00" max="20:30" step="900" value="<?= e($old['start_time']) ?>" required></div>
        <div><label>End time</label><input type="time" name="end_time" min="07:30" max="21:00" step="900" value="<?= e($old['end_time']) ?>" required></div>
        <div class="full-col"><label>Schedule (made for you)</label><input class="preview" name="schedule_preview" readonly tabindex="-1" placeholder="Pick the days and times above"></div>
      </div>
      <div class="field-err" id="subjClientErr" role="alert"></div>
      <div class="btns"><button type="submit">Add Subject</button><button type="button" class="sec" data-close-modal>Cancel</button></div>
    </form>
    </div>
  </dialog>

  <div class="card">
    <?= list_toolbar($lt, 'Search code, subject or schedule', [
      'course' => ['All courses', array_combine($programs, array_map('program_label', $programs))],
    ]) ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'code', 'Code') ?><?= sort_th($lt, 'name', 'Subject') ?><?= sort_th($lt, 'units', 'Units') ?><?= sort_th($lt, 'schedule', 'Schedule') ?><?= sort_th($lt, 'program', 'Course') ?><th>Action</th></tr>
      <?php if (!$lt['rows']) echo empty_row(6, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $s): ?>
        <tr>
          <td><?= e($s['code']) ?></td><td><?= e($s['name']) ?></td><td><?= e($s['units']) ?></td><td><?= e($s['schedule']) ?></td><td><?= e($s['program']) ?></td>
          <td>
            <form method="POST" class="inline-form" data-confirm="Remove subject <?= e($s['code']) ?> (<?= e($s['name']) ?>)? This can't be undone." data-confirm-title="Delete subject" data-confirm-btn="Delete" data-confirm-style="danger">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
              <button class="bad" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
</div>
</div>
<script>
(function () {
  var f = document.getElementById('subjForm');
  var order = ['M', 'T', 'W', 'Th', 'F', 'Sat', 'Sun'];
  function fmt(t) { return t ? String(parseInt(t.slice(0, 2), 10)) + t.slice(2) : ''; }
  function mins(t) { return parseInt(t.slice(0, 2), 10) * 60 + parseInt(t.slice(3, 5), 10); }
  function days() { return order.filter(function (d) { var c = f.querySelector('input[name="days[]"][value="' + d + '"]'); return c && c.checked; }); }
  function build() {
    var d = days(), s = f.elements.start_time.value, e = f.elements.end_time.value;
    return (d.length && s && e) ? d.join('') + ' ' + fmt(s) + '-' + fmt(e) : '';
  }
  function refresh() { f.elements.schedule_preview.value = build(); document.getElementById('subjClientErr').classList.remove('show'); }

  // Block characters that can never be valid, while typing
  f.elements.code.addEventListener('input', function () { this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
  f.elements.name.addEventListener('input', function () { this.value = this.value.replace(/[^\p{L}0-9 .,'&()\-]/gu, ''); });
  f.addEventListener('change', refresh);
  refresh();

  // Runs BEFORE the confirmation popup (see data-validate), so the popup only shows for a good form
  window.validateSubjectForm = function () {
    var msg = '', s = f.elements.start_time.value, e = f.elements.end_time.value;
    if (!days().length) msg = 'Select at least one class day.';
    else if (mins(e) <= mins(s)) msg = 'End time must be after the start time.';
    else if (mins(s) < 420 || mins(e) > 1260) msg = 'Class hours must be between 7:00 AM and 9:00 PM.';
    else if (mins(e) - mins(s) < 30) msg = 'A class must be at least 30 minutes long.';
    var box = document.getElementById('subjClientErr');
    box.textContent = msg; box.classList.toggle('show', !!msg);
    return msg === '';
  };
})();
</script>
</body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('admin');
$role = 'admin'; $active = 'Enrollment Requests';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $enrollId = (int)($_POST['enrollment_id'] ?? 0);
    $decision = $_POST['decision'] ?? '';

    if (!in_array($decision, ['approve', 'reject'], true)) {
        flash_set('err', 'Invalid action.');
        redirect_back();
    }
    $status = $decision === 'approve' ? 'approved' : 'rejected';

    // Only pending requests can be decided (prevents double-approving)
    $q = $conn->prepare("SELECT e.id, e.student_id, st.full_name, st.program, st.section_id
                         FROM enrollments e JOIN students st ON e.student_id = st.id
                         WHERE e.id = ? AND e.status = 'pending'");
    $q->bind_param("i", $enrollId); $q->execute();
    $enr = $q->get_result()->fetch_assoc();

    if (!$enr) {
        flash_set('err', 'That request was not found or has already been decided.');
        redirect_back();
    }

    $conn->begin_transaction();
    $u = $conn->prepare("UPDATE enrollments SET status = ? WHERE id = ?");
    $u->bind_param("si", $status, $enrollId); $u->execute();

    if ($status === 'approved' && !$enr['section_id']) {
        // Auto-assign to the section of the student's program with the fewest students
        $s = $conn->prepare("SELECT sec.id FROM sections sec WHERE sec.program = ?
                             ORDER BY (SELECT COUNT(*) FROM students x WHERE x.section_id = sec.id), sec.name LIMIT 1");
        $s->bind_param("s", $enr['program']); $s->execute();
        $sec = $s->get_result()->fetch_assoc();
        if ($sec) {
            $a = $conn->prepare("UPDATE students SET section_id = ? WHERE id = ?");
            $a->bind_param("ii", $sec['id'], $enr['student_id']); $a->execute();
        }
    }
    $conn->commit();
    log_activity($conn, ucfirst($status) . " enrollment of {$enr['full_name']}");
    flash_set('ok', $enr['full_name'] . ' enrollment ' . $status . '.');
    redirect_back();
}

$programs = program_codes();
$fc = allowed_get('course', $programs);
$where = ["e.status = 'pending'"]; $params = []; $types = '';
if ($fc !== '') { $where[] = 'st.program = ?'; $params[] = $fc; $types .= 's'; }
$filters = ['course' => ['All courses', array_combine($programs, $programs)]];

$lt = list_query($conn, [
    'select'   => 'e.id, e.submitted_at, st.student_id AS sid, st.full_name, st.program,
                   (SELECT COUNT(*) FROM enrollment_items ei WHERE ei.enrollment_id = e.id) AS subj_count',
    'from'     => 'enrollments e JOIN students st ON e.student_id = st.id',
    'where'    => $where, 'params' => $params, 'types' => $types,
    'search'   => ['st.full_name', 'st.student_id', 'st.program'],
    'sortable' => ['id' => 'st.student_id', 'name' => 'st.full_name', 'program' => 'st.program', 'subjects' => 'subj_count', 'date' => 'e.submitted_at'],
    'default_sort' => 'date', 'default_dir' => 'desc',
]);
echo page_head('Enrollment Requests');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Enrollment Requests</h1><span class="badge">Admin Panel</span></div>
  <?= flash_show() ?>

  <div class="card">
    <?= list_toolbar($lt, 'Search student name, ID or course', $filters) ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'id', 'ID') ?><?= sort_th($lt, 'name', 'Student') ?><?= sort_th($lt, 'program', 'Program') ?><?= sort_th($lt, 'subjects', 'Subjects') ?><?= sort_th($lt, 'date', 'Submitted') ?><th>Action</th></tr>
      <?php if (!$lt['rows']) echo empty_row(6, $lt['q'] ?: ''); ?>
      <?php foreach ($lt['rows'] as $r): ?>
        <tr>
          <td><?= e($r['sid']) ?></td><td><?= e($r['full_name']) ?></td>
          <td><?= e($r['program']) ?></td><td><?= (int)$r['subj_count'] ?> subjects</td>
          <td><?= e($r['submitted_at']) ?></td>
          <td>
            <?php foreach (['approve' => ['Approve', ''], 'reject' => ['Reject', 'bad']] as $d => [$lbl, $cls]): ?>
              <form method="POST" class="inline-form" data-confirm="<?= e(($d === 'approve' ? 'Approve' : 'Reject') . ' the enrollment of ' . $r['full_name'] . ' (' . $r['subj_count'] . ' subjects)?') ?>" data-confirm-title="<?= $d === 'approve' ? 'Approve enrollment' : 'Reject enrollment' ?>" data-confirm-btn="<?= $lbl ?>" <?= $d === 'reject' ? 'data-confirm-style="danger"' : '' ?>>
                <?= csrf_field() ?>
                <input type="hidden" name="enrollment_id" value="<?= (int)$r['id'] ?>">
                <input type="hidden" name="decision" value="<?= $d ?>">
                <button class="<?= $cls ?>" type="submit"><?= $lbl ?></button>
              </form>
            <?php endforeach; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
</div>
</div></body></html>

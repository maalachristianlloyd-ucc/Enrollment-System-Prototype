<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('admin');
$role = 'admin'; $active = 'Dashboard';

$pendingEnr = $conn->query("SELECT COUNT(*) c FROM enrollments WHERE status='pending'")->fetch_assoc()['c'];
$students = $conn->query("SELECT COUNT(*) c FROM students WHERE status='approved'")->fetch_assoc()['c'];
$subjects = $conn->query("SELECT COUNT(*) c FROM subjects")->fetch_assoc()['c'];
$sections = $conn->query("SELECT COUNT(*) c FROM sections")->fetch_assoc()['c'];

// Sections and approved students per course
$perCourse = [];
foreach (program_codes() as $p) $perCourse[$p] = ['sections' => 0, 'students' => 0];
foreach ($conn->query("SELECT program, COUNT(*) c FROM sections GROUP BY program") as $r)
    if (isset($perCourse[$r['program']])) $perCourse[$r['program']]['sections'] = (int)$r['c'];
foreach ($conn->query("SELECT program, COUNT(*) c FROM students WHERE status='approved' GROUP BY program") as $r)
    if (isset($perCourse[$r['program']])) $perCourse[$r['program']]['students'] = (int)$r['c'];
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>Admin Dashboard</title><link rel="stylesheet" href="<?= BASE_PATH ?>/assets/css/style.css"></head>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Dashboard</h1><span class="badge">Admin Panel</span></div>
  <div class="grid">
    <a class="card" href="requests.php"><div class="mu">Pending Enrollment Requests</div><div class="num"><?= (int)$pendingEnr ?></div></a>
    <a class="card" href="students.php"><div class="mu">Total Students</div><div class="num"><?= (int)$students ?></div></a>
    <a class="card" href="subjects.php"><div class="mu">Total Subjects</div><div class="num"><?= (int)$subjects ?></div></a>
    <a class="card" href="sections.php"><div class="mu">Total Sections</div><div class="num"><?= (int)$sections ?></div></a>
  </div>
  <div class="card">
    <h3>Sections per course</h3>
    <div class="tw"><table>
      <tr><th>Course</th><th>Total Sections</th><th>Students</th></tr>
      <?php foreach ($perCourse as $p => $v): ?>
        <tr><td><?= e($p) ?></td><td><?= $v['sections'] ?></td><td><?= $v['students'] ?></td></tr>
      <?php endforeach; ?>
    </table></div>
  </div>
  <div class="card">
    <h3>Needs attention</h3>
    <?= $pendingEnr ?> enrollment request(s) waiting.
    <a class="btn sec" href="requests.php">Review</a>
  </div>
</div>
</div></body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('admin');
$role = 'admin'; $active = 'Reports';

$type = $_GET['type'] ?? '';
if (!in_array($type, ['enrollment', 'class', 'registration'], true)) $type = '';

$lt = null; $filters = [];
if ($type === 'enrollment') {
    $statuses = ['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'];
    $fst = allowed_get('status', array_keys($statuses));
    $filters = ['status' => ['All statuses', $statuses]];
    $lt = list_query($conn, [
        'select'   => 'e.status, e.submitted_at, st.student_id AS sid, st.full_name',
        'from'     => 'enrollments e JOIN students st ON e.student_id = st.id',
        'where'    => $fst !== '' ? ['e.status = ?'] : [], 'params' => $fst !== '' ? [$fst] : [], 'types' => $fst !== '' ? 's' : '',
        'search'   => ['st.full_name', 'st.student_id'],
        'sortable' => ['id' => 'st.student_id', 'name' => 'st.full_name', 'status' => 'e.status', 'date' => 'e.submitted_at'],
        'default_sort' => 'date', 'default_dir' => 'desc',
    ]);
} elseif ($type === 'class') {
    $secOpts = [];
    foreach ($conn->query("SELECT id, name FROM sections ORDER BY name") as $sc) $secOpts[(string)$sc['id']] = $sc['name'];
    $fs = allowed_get('section', array_keys($secOpts));
    $filters = ['section' => ['All sections', $secOpts]];
    $lt = list_query($conn, [
        'select'   => 'sec.name AS sec_name, st.student_id AS sid, st.full_name',
        'from'     => 'students st JOIN sections sec ON st.section_id = sec.id',
        'where'    => $fs !== '' ? ["st.status = 'approved'", 'sec.id = ?'] : ["st.status = 'approved'"],
        'params'   => $fs !== '' ? [(int)$fs] : [], 'types' => $fs !== '' ? 'i' : '',
        'search'   => ['st.full_name', 'st.student_id'],
        'sortable' => ['section' => 'sec.name', 'id' => 'st.student_id', 'name' => 'st.full_name'],
        'default_sort' => 'section',
    ]);
}
echo page_head('Reports');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Reports</h1><span class="badge">Admin Panel</span></div>

  <div class="card">
    <h3>Generate Report</h3>
    <a class="btn <?= $type === 'enrollment' ? '' : 'sec' ?>" href="?type=enrollment">Enrollment List</a>
    <a class="btn <?= $type === 'class' ? '' : 'sec' ?>" href="?type=class">Class List per Section</a>
    <a class="btn <?= $type === 'registration' ? '' : 'sec' ?>" href="?type=registration">Registration Summary</a>
  </div>

  <?php if ($type === 'enrollment'): ?>
    <div class="card">
      <h3>Enrollment List</h3>
      <?= list_toolbar($lt, 'Search name or ID', $filters) ?>
      <div class="tw"><table>
        <tr><?= sort_th($lt, 'id', 'Student ID') ?><?= sort_th($lt, 'name', 'Name') ?><?= sort_th($lt, 'status', 'Status') ?><?= sort_th($lt, 'date', 'Date Submitted') ?></tr>
        <?php if (!$lt['rows']) echo empty_row(4, $lt['q']); ?>
        <?php foreach ($lt['rows'] as $row): ?>
          <tr><td><?= e($row['sid']) ?></td><td><?= e($row['full_name']) ?></td><td><?= e(ucfirst($row['status'])) ?></td><td><?= e($row['submitted_at']) ?></td></tr>
        <?php endforeach; ?>
      </table></div>
      <?= list_pagination($lt) ?>
    </div>

  <?php elseif ($type === 'class'): ?>
    <div class="card">
      <h3>Class List per Section</h3>
      <?= list_toolbar($lt, 'Search name or ID', $filters) ?>
      <div class="tw"><table>
        <tr><?= sort_th($lt, 'section', 'Section') ?><?= sort_th($lt, 'id', 'Student ID') ?><?= sort_th($lt, 'name', 'Name') ?></tr>
        <?php if (!$lt['rows']) echo empty_row(3, $lt['q']); ?>
        <?php foreach ($lt['rows'] as $row): ?>
          <tr><td><?= e($row['sec_name']) ?></td><td><?= e($row['sid']) ?></td><td><?= e($row['full_name']) ?></td></tr>
        <?php endforeach; ?>
      </table></div>
      <?= list_pagination($lt) ?>
    </div>

  <?php elseif ($type === 'registration'): ?>
    <div class="card">
      <h3>Registration Summary</h3>
      <?php
      $counts = ['approved' => 0, 'pending' => 0, 'rejected' => 0];
      $r = $conn->query("SELECT status, COUNT(*) c FROM students GROUP BY status");
      while ($row = $r->fetch_assoc()) $counts[$row['status']] = (int)$row['c'];
      ?>
      <div class="grid">
        <div class="card"><div class="mu">Approved</div><div class="num"><?= $counts['approved'] ?></div></div>
        <div class="card"><div class="mu">Pending</div><div class="num"><?= $counts['pending'] ?></div></div>
        <div class="card"><div class="mu">Rejected</div><div class="num"><?= $counts['rejected'] ?></div></div>
      </div>
    </div>
  <?php endif; ?>
</div>
</div></body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('admin');
$role = 'admin'; $active = 'Sections';
$programs = program_codes();
$letters  = range('A', 'J');
$old = ['program' => '', 'year' => '1', 'letter' => ''];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $old = ['program' => $_POST['program'] ?? '', 'year' => $_POST['year'] ?? '', 'letter' => strtoupper($_POST['letter'] ?? '')];
        $error = first_error([
            v_in($old['program'], $programs, 'program'),
            v_in($old['year'], ['1', '2', '3', '4'], 'year level'),
            v_in($old['letter'], $letters, 'section letter'),
        ]);
        // The name is BUILT from the three choices (e.g. "BSIT 1-A"), so it always matches the program
        $name = $error ? '' : "{$old['program']} {$old['year']}-{$old['letter']}";
        if (!$error) {
            $dup = $conn->prepare("SELECT id FROM sections WHERE name = ?");
            $dup->bind_param("s", $name); $dup->execute();
            if ($dup->get_result()->fetch_assoc()) $error = "Section $name already exists.";
        }
        if (!$error) {
            $stmt = $conn->prepare("INSERT INTO sections (name, program) VALUES (?,?)");
            $stmt->bind_param("ss", $name, $old['program']); $stmt->execute();
            log_activity($conn, "Added section $name");
            flash_set('ok', "Section $name added.");
            redirect_back();
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $q = $conn->prepare("SELECT s.name, (SELECT COUNT(*) FROM students st WHERE st.section_id = s.id) AS n FROM sections s WHERE s.id = ?");
        $q->bind_param("i", $id); $q->execute();
        $sec = $q->get_result()->fetch_assoc();
        if (!$sec) {
            flash_set('err', 'Section not found.');
        } elseif ((int)$sec['n'] > 0) {
            flash_set('err', "Section {$sec['name']} still has {$sec['n']} student(s). Move them to another section first.");
        } else {
            $d = $conn->prepare("DELETE FROM sections WHERE id = ?");
            $d->bind_param("i", $id); $d->execute();
            log_activity($conn, "Deleted section {$sec['name']}");
            flash_set('ok', "Section {$sec['name']} deleted.");
        }
        redirect_back();
    }
}

$fc = allowed_get('course', $programs);
$lt = list_query($conn, [
    'select'   => 'sec.*, (SELECT COUNT(*) FROM students s WHERE s.section_id = sec.id) AS student_count',
    'from'     => 'sections sec',
    'where'    => $fc !== '' ? ['sec.program = ?'] : [], 'params' => $fc !== '' ? [$fc] : [], 'types' => $fc !== '' ? 's' : '',
    'search'   => ['sec.name', 'sec.program'],
    'sortable' => ['name' => 'sec.name', 'program' => 'sec.program', 'students' => 'student_count'],
    'default_sort' => 'name',
]);
echo page_head('Sections');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Sections</h1><span class="badge">Admin Panel</span></div>
  <?= flash_show() ?>

  <div class="page-actions"><button type="button" data-open-modal="addModal">+ Add Section</button></div>
  <dialog class="modal form-modal" id="addModal" <?= $error ? 'data-open-on-load' : '' ?>>
    <div class="modal-head"><h3>Add Section</h3><button type="button" class="x" data-close-modal aria-label="Close">&times;</button></div>
    <div class="modal-form">
    <?php if ($error): ?><div class="err" role="alert" style="margin:0 0 10px"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" id="secForm" data-confirm="Add section {section_preview}?" data-confirm-title="Add section" data-confirm-btn="Add section">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <div class="row">
        <div><label>Program</label>
          <select name="program" required>
            <option value="">Select</option>
            <?php foreach ($programs as $p): ?><option <?= $old['program'] === $p ? 'selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div><label>Year level</label>
          <select name="year" required>
            <?php foreach (['1' => '1st Year', '2' => '2nd Year', '3' => '3rd Year', '4' => '4th Year'] as $v => $l): ?>
              <option value="<?= $v ?>" <?= $old['year'] === (string)$v ? 'selected' : '' ?>><?= $l ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div><label>Section letter</label>
          <select name="letter" required>
            <option value="">Select</option>
            <?php foreach ($letters as $l): ?><option <?= $old['letter'] === $l ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?>
          </select>
        </div>
        <div><label>Section name (made for you)</label><input class="preview" name="section_preview" readonly tabindex="-1" placeholder="e.g. BSIT 1-A"></div>
      </div>
      <div class="btns"><button type="submit">Add Section</button><button type="button" class="sec" data-close-modal>Cancel</button></div>
    </form>
    </div>
  </dialog>

  <div class="card">
    <?= list_toolbar($lt, 'Search section or program', ['course' => ['All courses', array_combine($programs, $programs)]]) ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'name', 'Section') ?><?= sort_th($lt, 'program', 'Program') ?><?= sort_th($lt, 'students', 'Students') ?><th>Action</th></tr>
      <?php if (!$lt['rows']) echo empty_row(4, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $s): ?>
        <tr>
          <td><?= e($s['name']) ?></td><td><?= e($s['program']) ?></td><td><?= (int)$s['student_count'] ?></td>
          <td>
            <form method="POST" class="inline-form" data-confirm="Delete section <?= e($s['name']) ?>? <?= (int)$s['student_count'] > 0 ? 'It still has students, so it will not be deleted until they are moved.' : 'This can\'t be undone.' ?>" data-confirm-title="Delete section" data-confirm-btn="Delete" data-confirm-style="danger">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
              <button class="bad" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
  <p class="mu">Assign students to a section from Student Records. Sections with students can't be deleted.</p>
</div>
</div>
<script>
(function () {
  var f = document.getElementById('secForm');
  function refresh() {
    var p = f.elements.program.value, y = f.elements.year.value, l = f.elements.letter.value;
    f.elements.section_preview.value = (p && y && l) ? p + ' ' + y + '-' + l : '';
  }
  f.addEventListener('change', refresh);
  refresh();
})();
</script>
</body></html>

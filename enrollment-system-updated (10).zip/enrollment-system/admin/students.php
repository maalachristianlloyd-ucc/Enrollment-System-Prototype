<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('admin');
$role = 'admin'; $active = 'Student Records';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['student_id'] ?? 0);

    $chk = $conn->prepare("SELECT id, full_name, program FROM students WHERE id = ? AND status = 'approved'");
    $chk->bind_param("i", $id); $chk->execute();
    $stu = $chk->get_result()->fetch_assoc();

    if (!$stu) {
        flash_set('err', 'Student not found.');
    } elseif ($action === 'delete') {
        $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
        $stmt->bind_param("i", $id); $stmt->execute();
        log_activity($conn, "Deleted student record: {$stu['full_name']}");
        flash_set('ok', 'Record deleted.');
    } elseif ($action === 'update_section') {
        $secId = ($_POST['section_id'] ?? '') !== '' ? (int)$_POST['section_id'] : null;
        $valid = true;
        if ($secId !== null) {
            // The section must exist and belong to the student's program
            $s = $conn->prepare("SELECT id FROM sections WHERE id = ? AND program = ?");
            $s->bind_param("is", $secId, $stu['program']); $s->execute();
            $valid = (bool)$s->get_result()->fetch_assoc();
        }
        if (!$valid) {
            flash_set('err', "That section doesn't exist or isn't for the student's course ({$stu['program']}).");
        } else {
            $stmt = $conn->prepare("UPDATE students SET section_id = ? WHERE id = ?");
            $stmt->bind_param("ii", $secId, $id); $stmt->execute();
            flash_set('ok', 'Section updated.');
        }
    }
    redirect_back();
}

// ----- dropdown filters: course + section -----
$programs = program_codes();
$sectionList = $conn->query("SELECT id, name, program FROM sections ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$secOpts = ['none' => 'Unassigned'];
foreach ($sectionList as $sc) $secOpts[(string)$sc['id']] = $sc['name'];
$fc = allowed_get('course', $programs);
$fs = allowed_get('section', array_map('strval', array_keys($secOpts)));
$where = ["s.status = 'approved'"]; $params = []; $types = '';
if ($fc !== '') { $where[] = 's.program = ?'; $params[] = $fc; $types .= 's'; }
if ($fs === 'none') { $where[] = 's.section_id IS NULL'; }
elseif ($fs !== '') { $where[] = 's.section_id = ?'; $params[] = (int)$fs; $types .= 'i'; }
$filters = ['course' => ['All courses', array_combine($programs, $programs)], 'section' => ['All sections', $secOpts]];

$lt = list_query($conn, [
    'select'   => 's.*, sec.name AS section_name',
    'from'     => 'students s LEFT JOIN sections sec ON s.section_id = sec.id',
    'where'    => $where, 'params' => $params, 'types' => $types,
    'search'   => ['s.full_name', 's.student_id', 's.program', 'sec.name'],
    'sortable' => ['id' => 's.student_id', 'name' => 's.full_name', 'program' => 's.program', 'section' => 'sec.name'],
    'default_sort' => 'name',
]);
echo page_head('Student Records');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Student Records</h1><span class="badge">Admin Panel</span></div>
  <?= flash_show() ?>

  <div class="card">
    <?= list_toolbar($lt, 'Search name, ID, course or section', $filters) ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'id', 'ID') ?><?= sort_th($lt, 'name', 'Name') ?><?= sort_th($lt, 'program', 'Program') ?><?= sort_th($lt, 'section', 'Section') ?><th>Action</th></tr>
      <?php if (!$lt['rows']) echo empty_row(5, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $s): ?>
        <tr>
          <td><?= e($s['student_id']) ?></td><td><?= e($s['full_name']) ?></td><td><?= e($s['program']) ?></td>
          <td>
            <form method="POST" style="display:flex;gap:4px" data-reset-on-cancel data-confirm="Change the section of <?= e($s['full_name']) ?>?" data-confirm-title="Change section" data-confirm-btn="Change">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="update_section">
              <input type="hidden" name="student_id" value="<?= (int)$s['id'] ?>">
              <select name="section_id" onchange="this.form.requestSubmit()" aria-label="Section">
                <option value="">Unassigned</option>
                <?php foreach ($sectionList as $sc): if ($sc['program'] !== $s['program']) continue; ?>
                  <option value="<?= (int)$sc['id'] ?>" <?= $s['section_id'] == $sc['id'] ? 'selected' : '' ?>><?= e($sc['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </form>
          </td>
          <td>
            <form method="POST" class="inline-form" data-confirm="Delete the record of <?= e($s['full_name']) ?> (<?= e($s['student_id']) ?>)? This also removes their enrollments and can't be undone." data-confirm-title="Delete student" data-confirm-btn="Delete" data-confirm-style="danger">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="student_id" value="<?= (int)$s['id'] ?>">
              <button class="bad" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
  <p class="mu">Note: New student records come from approved registrations (Staff approval) — this is a management/search view, not a manual add form.</p>
</div>
</div></body></html>

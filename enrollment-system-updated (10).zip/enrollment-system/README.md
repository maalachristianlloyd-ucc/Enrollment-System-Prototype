# Enrollment System (PHP + MySQL) — Localhost Setup

## Kailangan mo muna
- **XAMPP** (https://www.apachefriends.org) o **Laragon** (https://laragon.org) — alinman, libre.

## Hakbang-hakbang (XAMPP)

1. **I-install ang XAMPP**, tapos buksan ang XAMPP Control Panel.
2. I-**Start** ang **Apache** at **MySQL**.
3. Hanapin ang `htdocs` folder (halimbawa: `C:\xampp\htdocs`).
4. I-copy ang buong `enrollment-system` folder papunta sa loob ng `htdocs`.
   - Dapat ganito ang path: `C:\xampp\htdocs\enrollment-system\index.php`
5. Buksan ang browser, pumunta sa **http://localhost/phpmyadmin**
6. I-click ang **Import** tab, piliin ang file na `sql/schema.sql` (nasa loob ng enrollment-system folder), tapos i-click ang **Go**.
   - Gagawa ito ng database na `enrollment_system` kasama ang lahat ng tables at sample data.
7. Buksan ang: **http://localhost/enrollment-system/**

Tapos na! Dapat makita mo na ang Log in page.

## Hakbang-hakbang (Laragon) — mas simple

1. I-install ang Laragon, i-click ang **Start All**.
2. I-right-click ang Laragon tray icon → **www directory** (o hanapin ang `laragon/www`).
3. I-copy ang `enrollment-system` folder doon.
4. Buksan ang **http://localhost/phpmyadmin**, i-import ang `sql/schema.sql`.
5. Buksan ang **http://localhost/enrollment-system/**

## Login Pages (hiwalay na ngayon)

| Para kanino | URL | Ginagamit |
|---|---|---|
| **Student** | `http://localhost/enrollment-system/` (`index.php`) | Student ID (hal. `20250775-C`) |
| **Staff / Admin** (kasama ang Superadmin) | `http://localhost/enrollment-system/staff-login.php` | Username |

- Hindi makaka-login ang Staff/Admin sa Student page, at hindi makaka-login ang Student sa Staff page.
- Kapag nag-login ang isang role at pumunta sa maling portal, ibabalik siya sa sarili niyang dashboard.
- Pagkatapos ng 5 maling login, naka-lock ng 5 minuto.

| Account | ID / Username | Password | Login page |
|---|---|---|---|
| Student (approved) | `20250775-C` | `student123` | index.php |
| Student (pending — para subukan ang Staff approval) | `20260101-C` | `student123` | index.php |
| Staff | `staff1` | `staff123` | staff-login.php |
| Admin | `admin1` | `admin123` | staff-login.php |
| Superadmin | `superadmin` | `super123` | staff-login.php |

## Buong Flow na Masusubukan

1. **Mag-register ng bagong student** sa `/enrollment-system/register.php`. Makakakuha ng Student ID na "pending."
2. Subukang mag-login gamit ang bagong account → lalabas na "pending Staff approval."
3. **Mag-login bilang Staff** (`staff1` / `staff123`) → pumunta sa **Pending Registrations** → i-**Approve** ang bagong registrant.
4. Bumalik sa login, gamitin na ang bagong student account → gagana na ang login.
5. **Mag-login bilang Student** (`20250775-C` / `student123`) → pumunta sa **Enrollment** → pumili ng subjects → i-review → i-submit. Magiging "Pending Admin approval."
6. **Mag-login bilang Admin** (`admin1` / `admin123`) → **Enrollment Requests** → i-Approve. Awtomatikong ma-a-assign sa section base sa program.
7. Bumalik sa Student account → makikita na sa **My Schedule** ang mga na-enroll na subjects.

## Folder Structure

```
enrollment-system/
├── config/db.php          ← database connection settings
├── sql/schema.sql          ← import this in phpMyAdmin
├── includes/
│   ├── auth.php            ← session + role guard
│   ├── helpers.php         ← search, sort, pagination, validation, CSRF
│   └── sidebar.php         ← dynamic nav per role
├── assets/css/style.css    ← white + dark green theme
├── index.php                ← STUDENT login page
├── staff-login.php          ← STAFF / ADMIN login page
├── register.php             ← student registration
├── logout.php
├── student/                 ← dashboard, profile, subjects, enrollment, schedule
├── staff/                   ← dashboard, pending registrations, search
└── admin/                   ← dashboard, enrollment requests, students, subjects, sections, reports
```

## Mga Tandaan
- Gumagamit ng **prepared statements** (bind_param) ang lahat ng query na may user input, para secure sa SQL injection.
- **password_hash() / password_verify()** ang ginagamit para sa passwords, hindi plain text.
- Kung iba ang MySQL username/password mo (hindi `root` / blangko), i-edit ang `config/db.php`.
- Walang kasamang "Add Student" form sa Admin dahil ang bagong student ay dapat dumaan muna sa Registration → Staff Approval flow. Pwede namang i-edit/i-delete ng Admin ang existing records.

## Superadmin (bago)
- Ang **Superadmin** lang ang pwedeng gumawa ng Admin, Staff at Superadmin accounts (Manage Accounts). Hindi na pwedeng mag-add ng account ang Admin.
- Pwedeng **i-reset ang password** ng kahit anong account (student, staff, admin). Hindi mababasa ang lumang password dahil naka-encrypt (password_hash) — mas secure ito.
- **Activity Log**: makikita kung sino ang nag-login, nag-logout, gumawa/nag-delete ng account at nag-reset ng password.
- Kung na-import mo na dati ang `schema.sql`, i-import na lang ang `sql/add_superadmin.sql` para hindi mabura ang data mo.
- Palitan agad ang password ng `superadmin` pagkatapos ng unang login.

## Freshmen-only + Course-based subjects (bago)
- Registration ay para sa **freshmen lang** — awtomatikong `1st Year` ang lahat ng bagong student (walang Year Level field).
- Ang bawat **subject** ay may **Course** (BSIT, BSCS, BSIS, BSEMC o `ALL` para sa common subjects tulad ng English/PE). Ang student ay makikita at makakapili lang ng subjects ng course niya + `ALL`.
- Tinanggal na ang **My Grades** page.
- Hindi na makikita ang **Superadmin** sa Create Account dropdown (Admin at Staff lang).
- Kung na-import mo na dati ang `schema.sql`, i-run lang ang `sql/add_subject_program.sql` (isang beses).
- Pagkatapos, sa Admin panel, mag-add ng subjects at sections para sa BSCS, BSIS at BSEMC.

## Search, Sort at Pagination (bago)
- Lahat ng table (Student Records, Subjects, Sections, Enrollment Requests, Reports, Pending Registrations, Search Students, Subject List, Manage Accounts, Activity Log) ay may **search bar**, **click-to-sort na column headers** (▲/▼) at **pagination** (Prev / numbers / Next + 10/25/50 per page).
- Para magdagdag sa ibang table: tingnan ang `list_query()` sa `includes/helpers.php` at ang `admin/subjects.php` bilang halimbawa.

## Validation (inayos)
- **Server-side** (hindi ma-bypass) at **client-side** (agad na error sa ilalim ng field): Registration, Profile, Subjects, Sections, Accounts, Login.
- Mga rules: pangalan (letters lang), birthday (14–60 taong gulang, hindi future), contact number (11 digits, nagsisimula sa `09`), email (valid at hindi pwedeng i-duplicate), password (**8+ characters na may letra at numero**), subject code/units/schedule, section name (walang duplicate), username (4–30 chars).
- Enrollment: kailangan ng kahit isang subject, may max na 30 units.
- Seguridad: lahat ng query ay prepared statements na ngayon; ang Delete ay POST na (hindi na link) at may **CSRF token** ang lahat ng form; hindi pwedeng i-delete ang subject na may enrollment na; hindi pwedeng i-delete ang huling Superadmin.
- Hindi na kailangang mag-import ng bagong SQL — walang binago sa database.
- Kailangan ng **PHP 7.4 pataas** (XAMPP/Laragon na bago ay okay na).

## Logo
- Ang logo ay nasa `assets/img/logo.png` (at `favicon.png`). Palitan lang ang file para magpalit ng logo — lalabas ito sa lahat ng login page, sidebar at tab icon.

## Forgot Password (gumagana kahit offline)
- Login page -> **Forgot password?** -> ilalagay ng student ang **Student ID, Birthday, Registered email at Contact number**. Kapag LAHAT ay tugma sa record, makakapili na siya ng bagong password.
- Seguridad: iisang error message kahit alin ang mali; 5 maling try = naka-lock ng 2 minuto; 10 maling try bawat account = naka-lock ng 15 minuto; approved students lang; naka-save sa Activity Log (kasama ang failed attempts).
- Kung nakalimutan ang lahat ng detalye: i-reset ng Superadmin sa Manage Accounts.
- (Optional na upgrade) May kasamang emailed-link version (`reset-password.php`, `config/mail.php`) pero hindi ito naka-link sa UI. Kailangan nito ng internet + Gmail App Password.

## Mga bagong features (panelist list)
- **Modals:** lahat ng Delete / Approve / Reject / Reset password / Change section / Submit enrollment / Save profile / Log out ay may **confirmation modal** na (hindi na browser popup). Ang **Add Subject / Add Section / Add Account** ay bukas sa modal (`+ Add ...` button) para lumuwag ang table.
- **Filtering (dropdown):** Subjects (course), Student Records (course + section), Enrollment Requests (course), Pending Registrations (course), Search Students (course + section), Reports (status / section), Activity Log (role). Gumagana kasama ng search, sort at pagination.
- **Dashboard:** Admin — Total Students / Subjects / Sections (clickable) + Sections per course. Superadmin — may Total Sections at Total Subjects na rin.
- **Maximize space:** tinanggal ang max-width ng main content, mas manipis ang sidebar.
- **Online:** basahin ang `HOSTING.md`. Gamitin ang `sql/schema_hosting.sql` sa hosting (hindi ang `schema.sql`). Awtomatiko na ang folder path (`BASE_PATH`), kaya gagana ito sa `localhost/enrollment-system` at sa root ng hosting.

## Camarin campus (BS Criminology, BS Accountancy)
- Registration: pumili muna ng **Campus**, tapos lalabas lang ang mga program ng campus na iyon (Congressional: BSIT/BSCS/BSIS/BSEMC · Camarin: BSCRIM/BSA). May check din sa server.
- Ang listahan ng mga campus at program ay nasa iisang lugar lang: `program_catalog()` sa `includes/helpers.php`.
- Subjects: `ALL` = lahat ng program, `CSD` = BSIT/BSCS/BSIS/BSEMC lang, o isang program lang.
- Para sa lumang database: i-import ang `sql/add_camarin_programs.sql` (isang beses). Sample lang ang mga subject ng Camarin, palitan ng totoong curriculum.

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('superadmin');
$role = 'superadmin'; $active = 'Manage Accounts';
$error = '';
$old = ['type' => 'admin', 'full_name' => '', 'username' => ''];

// Allowed account types -> table + login column (whitelist: never built from user text)
$types = [
  'admin' => ['admins', 'username'],
  'staff' => ['staff', 'username'],
  'superadmin' => ['superadmins', 'username'],
  'student' => ['students', 'student_id'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $type = $_POST['type'] ?? '';
    if (!isset($types[$type])) { $error = 'Unknown account type.'; }
    else {
        [$table, $col] = $types[$type];

        if ($action === 'add') {
            $old = ['type' => $type, 'full_name' => trim($_POST['full_name'] ?? ''), 'username' => trim($_POST['username'] ?? '')];
            $p = $_POST['password'] ?? '';
            $error = first_error([
                in_array($type, ['admin', 'staff'], true) ? '' : 'You can only create Admin or Staff accounts here.',
                v_name($old['full_name']),
                v_username($old['username']),
                v_password($p),
            ]);
            if (!$error) {
                // Username must be unique across every account type (case-insensitive)
                foreach (['admins', 'staff', 'superadmins'] as $t) {
                    $s = $conn->prepare("SELECT 1 FROM $t WHERE username = ?");
                    $s->bind_param("s", $old['username']); $s->execute();
                    if ($s->get_result()->fetch_row()) { $error = 'That username is already used.'; break; }
                }
            }
            if (!$error) {
                $hash = password_hash($p, PASSWORD_DEFAULT);
                $s = $conn->prepare("INSERT INTO $table (username, password, full_name) VALUES (?,?,?)");
                $s->bind_param("sss", $old['username'], $hash, $old['full_name']); $s->execute();
                log_activity($conn, "Created $type account: {$old['username']}");
                flash_set('ok', ucfirst($type) . " account \"{$old['username']}\" created.");
                redirect_back();
            }
        }

        if ($action === 'reset') {
            $id = (int)($_POST['id'] ?? 0); $p = $_POST['new_password'] ?? '';
            $error = v_password($p);
            if (!$error) {
                $c = $conn->prepare("SELECT id FROM $table WHERE id = ?");
                $c->bind_param("i", $id); $c->execute();
                if (!$c->get_result()->fetch_assoc()) $error = 'Account not found.';
            }
            if (!$error) {
                $hash = password_hash($p, PASSWORD_DEFAULT);
                $s = $conn->prepare("UPDATE $table SET password = ? WHERE id = ?");
                $s->bind_param("si", $hash, $id); $s->execute();
                log_activity($conn, "Reset password of $type account #$id");
                flash_set('ok', 'Password reset. Give the new password to the account owner.');
                redirect_back();
            }
        }

        if ($action === 'delete' && in_array($type, ['admin', 'staff', 'superadmin'], true)) {
            $id = (int)($_POST['id'] ?? 0);
            if ($type === 'superadmin' && $id === (int)$_SESSION['id']) { $error = 'You cannot delete your own account.'; }
            else {
                if ($type === 'superadmin') {
                    $n = (int)$conn->query("SELECT COUNT(*) c FROM superadmins")->fetch_assoc()['c'];
                    if ($n <= 1) $error = 'You cannot delete the last Superadmin account.';
                }
                if (!$error) {
                    $s = $conn->prepare("DELETE FROM $table WHERE id = ?");
                    $s->bind_param("i", $id); $s->execute();
                    log_activity($conn, "Deleted $type account #$id");
                    flash_set('ok', 'Account deleted.');
                    redirect_back();
                }
            }
        }
    }
}

$addError = ($error && ($_POST['action'] ?? '') === 'add') ? $error : '';   // shown inside the Add Account window
$view = $_GET['view'] ?? 'admin';
if (!isset($types[$view])) $view = 'admin';
[$vt, $vc] = $types[$view];
$lt = list_query($conn, [
    'select'   => "id, $vc AS login, full_name" . ($view === 'student' ? ', status' : ''),
    'from'     => $vt,
    'search'   => [$vc, 'full_name'],
    'sortable' => ['login' => $vc, 'name' => 'full_name', 'id' => 'id'] + ($view === 'student' ? ['status' => 'status'] : []),
    'default_sort' => 'id',
]);
echo page_head('Manage Accounts');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Manage Accounts</h1><span class="badge">Superadmin Panel</span></div>
  <?= flash_show() ?>
  <?php if ($error && !$addError): ?><div class="err" role="alert" style="margin:0 0 12px"><?= e($error) ?></div><?php endif; ?>

  <div class="page-actions"><button type="button" data-open-modal="addModal">+ Add Account</button></div>
  <dialog class="modal form-modal" id="addModal" <?= $addError !== '' ? 'data-open-on-load' : '' ?>>
    <div class="modal-head"><h3>Add Account</h3><button type="button" class="x" data-close-modal aria-label="Close">&times;</button></div>
    <div class="modal-form">
    <?php if ($addError): ?><div class="err" role="alert" style="margin:0 0 10px"><?= e($addError) ?></div><?php endif; ?>
    <p class="mu">Only the Superadmin can create Admin and Staff accounts. They sign in at <b>staff-login.php</b>. Students still sign up through Registration.</p>
    <form method="POST" id="accForm" data-confirm="Create the {type} account for {full_name} (username: {username})?" data-confirm-title="Create account" data-confirm-btn="Create account">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add">
      <div class="row">
        <div><label>Account Type</label>
          <select name="type"><option value="admin" <?= $old['type']==='admin'?'selected':'' ?>>Admin</option><option value="staff" <?= $old['type']==='staff'?'selected':'' ?>>Staff</option></select></div>
        <div><label>Full Name</label><input name="full_name" maxlength="100" value="<?= e($old['full_name']) ?>" required></div>
        <div><label>Username</label><input name="username" maxlength="30" pattern="[A-Za-z0-9_.]{4,30}" title="4–30 characters: letters, numbers, _ or ." value="<?= e($old['username']) ?>" required></div>
        <div><label>Password (min. 8 characters, letters + numbers)</label><input name="password" type="password" data-pw minlength="8" maxlength="72" required></div>
      </div>
      <div class="btns"><button type="submit">Create Account</button><button type="button" class="sec" data-close-modal>Cancel</button></div>
    </form>
    </div>
  </dialog>

  <div class="card">
    <h3>All Accounts</h3>
    <p>
      <?php foreach (['admin'=>'Admins','staff'=>'Staff','superadmin'=>'Superadmins','student'=>'Students'] as $k => $lbl): ?>
        <a class="btn <?= $view === $k ? '' : 'sec' ?>" href="?view=<?= $k ?>"><?= $lbl ?></a>
      <?php endforeach; ?>
    </p>
    <p class="mu">Passwords are stored encrypted, so nobody (not even the Superadmin) can read them. You can set a new one instead.</p>
    <?= list_toolbar($lt, 'Search username / ID or name') ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'login', 'Username / ID') ?><?= sort_th($lt, 'name', 'Full Name') ?><?php if ($view === 'student') echo sort_th($lt, 'status', 'Status'); ?><th>Reset Password</th><th>Action</th></tr>
      <?php if (!$lt['rows']) echo empty_row($view === 'student' ? 5 : 4, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $r): ?>
        <tr>
          <td><?= e($r['login']) ?></td>
          <td><?= e($r['full_name']) ?></td>
          <?php if ($view === 'student'): ?><td><?= e(ucfirst($r['status'])) ?></td><?php endif; ?>
          <td>
            <form method="POST" style="display:flex;gap:6px" data-confirm="Set a new password for <?= e($r['full_name']) ?> (<?= e($r['login']) ?>)? Their old password will stop working." data-confirm-title="Reset password" data-confirm-btn="Reset">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="reset"><input type="hidden" name="type" value="<?= e($view) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input name="new_password" type="password" placeholder="New password" minlength="8" maxlength="72" required>
              <button class="sec" type="submit">Reset</button>
            </form>
          </td>
          <td>
            <?php if ($view !== 'student' && !($view === 'superadmin' && (int)$r['id'] === (int)$_SESSION['id'])): ?>
            <form method="POST" data-confirm="Delete the account of <?= e($r['full_name']) ?> (<?= e($r['login']) ?>)? This can't be undone." data-confirm-title="Delete account" data-confirm-btn="Delete" data-confirm-style="danger">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete"><input type="hidden" name="type" value="<?= e($view) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="bad" type="submit">Delete</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
</div>
</div>
<script src="<?= BASE_PATH ?>/assets/js/password.js"></script>
<script>
(function () {
  var f = document.getElementById('accForm'); if (!f) return;
  // Block characters that can never be valid, while typing
  f.elements.full_name.addEventListener('input', function () { this.value = this.value.replace(/[^\p{L}\s.'\-]/gu, ''); });
  f.elements.username.addEventListener('input', function () { this.value = this.value.replace(/[^A-Za-z0-9_.]/g, ''); });
})();
</script>
</body></html>

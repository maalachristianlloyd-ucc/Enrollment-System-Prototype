<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('superadmin');
$role = 'superadmin'; $active = 'Activity Log';

$roles = ['student' => 'Student', 'staff' => 'Staff', 'admin' => 'Admin', 'superadmin' => 'Superadmin'];
$fr = allowed_get('role', array_keys($roles));
$filters = ['role' => ['All roles', $roles]];

$lt = list_query($conn, [
    'select'   => '*',
    'from'     => 'activity_logs',
    'where'    => $fr !== '' ? ['actor_role = ?'] : [], 'params' => $fr !== '' ? [$fr] : [], 'types' => $fr !== '' ? 's' : '',
    'search'   => ['actor_name', 'action', 'actor_role'],
    'sortable' => ['when' => 'id', 'who' => 'actor_name', 'role' => 'actor_role', 'action' => 'action'],
    'default_sort' => 'when', 'default_dir' => 'desc',
    'per_page' => 25,
]);
echo page_head('Activity Log');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Activity Log</h1><span class="badge">Superadmin Panel</span></div>
  <div class="card">
    <?= list_toolbar($lt, 'Search name, role or action', $filters) ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'when', 'When') ?><?= sort_th($lt, 'who', 'Who') ?><?= sort_th($lt, 'role', 'Role') ?><?= sort_th($lt, 'action', 'Action') ?></tr>
      <?php if (!$lt['rows']) echo empty_row(4, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $l): ?>
        <tr><td><?= e($l['created_at']) ?></td><td><?= e($l['actor_name']) ?></td><td><?= e(ucfirst($l['actor_role'])) ?></td><td><?= e($l['action']) ?></td></tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
</div>
</div></body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('superadmin');
$role = 'superadmin'; $active = 'Dashboard';
$c = fn($sql) => $conn->query($sql)->fetch_assoc()['c'];
$students = $c("SELECT COUNT(*) c FROM students");
$staff = $c("SELECT COUNT(*) c FROM staff");
$admins = $c("SELECT COUNT(*) c FROM admins");
$supers = $c("SELECT COUNT(*) c FROM superadmins");
$sections = $c("SELECT COUNT(*) c FROM sections");
$subjects = $c("SELECT COUNT(*) c FROM subjects");
$logs = $conn->query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 10");
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>Superadmin Dashboard</title><link rel="stylesheet" href="<?= BASE_PATH ?>/assets/css/style.css"></head>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Dashboard</h1><span class="badge">Superadmin Panel</span></div>
  <div class="grid">
    <div class="card"><div class="mu">Total Students</div><div class="num"><?= $students ?></div></div>
    <div class="card"><div class="mu">Staff</div><div class="num"><?= $staff ?></div></div>
    <div class="card"><div class="mu">Admins</div><div class="num"><?= $admins ?></div></div>
    <div class="card"><div class="mu">Superadmins</div><div class="num"><?= $supers ?></div></div>
    <div class="card"><div class="mu">Total Sections</div><div class="num"><?= $sections ?></div></div>
    <div class="card"><div class="mu">Total Subjects</div><div class="num"><?= $subjects ?></div></div>
  </div>
  <div class="card">
    <h3>Recent activity</h3>
    <div class="tw"><table>
      <tr><th>When</th><th>Who</th><th>Role</th><th>Action</th></tr>
      <?php while ($l = $logs->fetch_assoc()): ?>
        <tr><td><?= e($l['created_at']) ?></td><td><?= e($l['actor_name']) ?></td><td><?= e(ucfirst($l['actor_role'])) ?></td><td><?= e($l['action']) ?></td></tr>
      <?php endwhile; ?>
    </table></div>
    <br><a class="btn sec" href="logs.php">View full log</a>
  </div>
</div>
</div></body></html>

# Putting the Enrollment System Online

Two ways. Option A gives a permanent link. Option B is the safest backup for defense day.
You can do **both**.

---

## Option A: Free hosting (InfinityFree) — permanent link

> Free hosts can be slow or go down sometimes. Test it the day BEFORE your defense.

1. **Sign up** at infinityfree.com and create a hosting account. Pick a free subdomain
   (example: `ucc-enrollment.rf.gd`).
2. **Create the database.** In the control panel open **MySQL Databases** and create one.
   Write down these 4 things: **host** (looks like `sql123.infinityfree.com`), **database name**,
   **username**, **password**.
3. **Import the tables.** Open **phpMyAdmin** from the control panel, click your database on the left,
   click **Import**, choose **`sql/schema_hosting.sql`** (NOT `schema.sql`), click **Import**.
4. **Edit `config/db.php`** and type the 4 things from step 2:
   ```php
   $DB_HOST = "sql123.infinityfree.com";
   $DB_USER = "if0_12345678";
   $DB_PASS = "your-password";
   $DB_NAME = "if0_12345678_enrollment";
   ```
5. **Edit `config/mail.php`:** set `BASE_URL` to your live address, e.g. `https://ucc-enrollment.rf.gd`
   (no slash at the end), and fill in the Gmail App Password (steps are at the top of that file).
6. **Upload the files.** Use the File Manager (or FileZilla). Open the **`htdocs`** folder, delete the
   default files, and upload everything inside the `enrollment-system` folder (so `index.php`
   sits directly in `htdocs`).
7. **Open your link.** Students: `https://your-site/`  ·  Staff/Admin: `https://your-site/staff-login.php`
8. **Change the default passwords** (superadmin / admin1 / staff1 / the sample student) in Manage Accounts.

**About email:** InfinityFree turns off PHP's normal `mail()`, but it allows sending through an outside
SMTP service such as Gmail. This system already uses PHPMailer + Gmail SMTP, so Forgot Password should work.
Send yourself a test reset email. If it doesn't work, the Superadmin can still reset any student's
password in Manage Accounts.

---

## Option B: Run it on your laptop and share it with a tunnel (backup plan)

Your XAMPP stays as it is. A tunnel gives your laptop a public link for a while.

1. Start Apache and MySQL in XAMPP. Make sure `http://localhost/enrollment-system/` works.
2. Install **ngrok** (ngrok.com, free account) or **cloudflared** (Cloudflare Tunnel).
3. Run ONE of these in a terminal:
   ```
   ngrok http 80
   cloudflared tunnel --url http://localhost:80
   ```
4. It prints a public `https://....` address. Open `https://that-address/enrollment-system/`.
5. For Forgot Password emails to work, set `BASE_URL` in `config/mail.php` to
   `https://that-address/enrollment-system` (the address changes each time you start the tunnel).

Your laptop must stay on and connected. Close the tunnel after the defense.

---

## Checklist before the defense
- [ ] Student login works at the live link
- [ ] Staff/Admin login works at `/staff-login.php`
- [ ] Register a test student, approve it as Staff, enroll, approve as Admin
- [ ] Forgot Password email arrives (check Spam)
- [ ] Default passwords changed
- [ ] You know your backup: Option B on your laptop

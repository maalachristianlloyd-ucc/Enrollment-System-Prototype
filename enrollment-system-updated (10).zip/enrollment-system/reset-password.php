<?php
// STUDENT RESET PASSWORD — opened from the link in the email.
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

if (isset($_SESSION['role'])) { header("Location: " . dashboard_url_for($_SESSION['role'])); exit; }

$token = $_POST['token'] ?? ($_GET['token'] ?? '');
$token = preg_match('/^[a-f0-9]{64}$/', $token) ? $token : '';
$error = '';
$row = null;

if ($token !== '') {
    $hash = hash('sha256', $token);
    // Valid = not used, not expired, and the student is still approved
    $stmt = $conn->prepare("SELECT pr.id, pr.student_id, s.full_name
                            FROM password_resets pr JOIN students s ON s.id = pr.student_id
                            WHERE pr.token_hash = ? AND pr.used = 0 AND pr.expires_at > NOW() AND s.status = 'approved'");
    $stmt->bind_param("s", $hash); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
}

if ($row && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $pw = $_POST['password'] ?? '';
    $cf = $_POST['confirm_password'] ?? '';
    $error = first_error([v_password($pw), ($pw !== $cf) ? 'Passwords do not match.' : '']);

    if (!$error) {
        $hashPw = password_hash($pw, PASSWORD_DEFAULT);
        $conn->begin_transaction();
        $u = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
        $u->bind_param("si", $hashPw, $row['student_id']); $u->execute();
        // The link works once; also cancel any other open links for this student
        $m = $conn->prepare("UPDATE password_resets SET used = 1 WHERE student_id = ?");
        $m->bind_param("i", $row['student_id']); $m->execute();
        $conn->commit();

        $l = $conn->prepare("INSERT INTO activity_logs (actor_role, actor_name, action) VALUES ('student', ?, 'Reset password (email link)')");
        $l->bind_param("s", $row['full_name']); $l->execute();

        flash_set('ok', 'Password changed. You can now log in with your new password.');
        header("Location: index.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title>Reset Password · University Enrollment Portal</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="stylesheet" href="assets/css/style.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head><body>
<div class="split">
  <div class="left">
    <div class="brand">
      <img class="logo-img" src="assets/img/logo.png" alt="School logo" width="44" height="44">
      <div><b>University Enrollment System</b><small>Student Portal</small></div>
    </div>
    <div>
      <span class="eyebrow hide-sm">Account Recovery</span>
      <h1>Choose a new password</h1>
      <div class="mu-dark hide-sm">Pick a strong password you will remember. It needs 8+ characters with a letter and a number.</div>
    </div>
    <div class="info-box hide-sm">
      <div class="mu-dark">Need help?</div>
      <div style="margin-top:6px">Visit the registrar and ask for a password reset.</div>
    </div>
  </div>
  <div class="right"><div class="box">
    <?php if (!$row): ?>
      <div class="box-head">
        <span class="eyebrow">Link problem</span>
        <h1>This link doesn't work</h1>
      </div>
      <div class="err" role="alert" style="margin:0 0 12px">This reset link is invalid, already used, or has expired.</div>
      <a class="btn" href="forgot-password.php" style="display:inline-block">Get a new link</a>
      <div class="auth-foot mu"><a href="index.php">← Back to login</a></div>
    <?php else: ?>
    <div class="box-head">
      <span class="eyebrow">Student Account</span>
      <h1>New password</h1>
      <div class="mu">Hi <?= e($row['full_name']) ?>, choose your new password.</div>
    </div>
    <?php if ($error): ?><div class="err" role="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" id="resetForm" novalidate style="margin-top:8px">
      <?= csrf_field() ?>
      <input type="hidden" name="token" value="<?= e($token) ?>">
      <label for="password">New password</label>
      <input id="password" name="password" type="password" data-pw minlength="8" maxlength="72" autocomplete="new-password" placeholder="At least 8 characters, letters and numbers" autofocus required>
      <div class="field-err" data-for="password">Password needs 8+ characters with a letter and a number.</div>
      <label for="confirm_password">Confirm new password</label>
      <input id="confirm_password" name="confirm_password" type="password" data-pw maxlength="72" autocomplete="new-password" placeholder="Re-enter new password" required>
      <div class="field-err" data-for="confirm_password">Passwords do not match.</div>
      <button class="full" type="submit">Change password</button>
    </form>
    <?php endif; ?>
  </div></div>
</div>
<script src="assets/js/password.js"></script>
<script>
(function () {
  var f = document.getElementById('resetForm'); if (!f) return;
  f.addEventListener('submit', function (ev) {
    var p = f.elements.password, c = f.elements.confirm_password;
    var pBad = p.value.length < 8 || !/[A-Za-z]/.test(p.value) || !/[0-9]/.test(p.value);
    var cBad = c.value !== p.value;
    [[p, pBad, 'password'], [c, cBad, 'confirm_password']].forEach(function (t) {
      t[0].classList.toggle('invalid', t[1]);
      document.querySelector('[data-for="' + t[2] + '"]').classList.toggle('show', t[1]);
    });
    if (pBad || cBad) ev.preventDefault();
  });
})();
</script>
</body></html>

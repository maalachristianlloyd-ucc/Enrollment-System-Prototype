<?php
// STUDENT FORGOT PASSWORD (works offline - no email or internet needed)
// The student proves who they are with 4 details that must ALL match their registration:
//   Student ID + Birthday + Registered email + Contact number
// then chooses a new password.
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

if (isset($_SESSION['role'])) { header("Location: " . dashboard_url_for($_SESSION['role'])); exit; }

$error = '';
$f = ['student_id' => '', 'birthday' => '', 'email' => '', 'contact_number' => ''];
$MAX_FAILS_PER_ACCOUNT = 10;   // wrong tries allowed per student account within 15 minutes

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $f = [
        'student_id'     => strtoupper(trim($_POST['student_id'] ?? '')),
        'birthday'       => trim($_POST['birthday'] ?? ''),
        'email'          => strtolower(trim($_POST['email'] ?? '')),
        'contact_number' => trim($_POST['contact_number'] ?? ''),
    ];
    $pw = $_POST['password'] ?? '';
    $cf = $_POST['confirm_password'] ?? '';

    if (reset_locked()) {
        $error = 'Too many failed attempts. Please wait ' . ceil(LOGIN_LOCK_SECONDS / 60) . ' minutes and try again.';
    } else {
        $error = first_error([
            preg_match('/^[0-9]{8}-[A-Z]$/', $f['student_id']) ? '' : 'Student ID format is invalid. It looks like 20250775-C.',
            v_birthday_any($f['birthday']),
            v_email($f['email']),
            v_phone($f['contact_number']),
            v_password($pw),
            ($pw !== $cf) ? 'Passwords do not match.' : '',
        ]);

        if (!$error) {
            $stmt = $conn->prepare("SELECT id, full_name, birthday, email, contact_number, status FROM students WHERE student_id = ?");
            $stmt->bind_param("s", $f['student_id']);
            $stmt->execute();
            $stu = $stmt->get_result()->fetch_assoc();

            // Per-account lock: stops someone guessing details for one student by clearing their cookies
            if ($stu) {
                $c = $conn->prepare("SELECT COUNT(*) c FROM activity_logs
                                     WHERE actor_role = 'student' AND actor_name = ? AND action = 'Failed password reset attempt'
                                       AND created_at > (NOW() - INTERVAL 15 MINUTE)");
                $c->bind_param("s", $stu['full_name']); $c->execute();
                if ((int)$c->get_result()->fetch_assoc()['c'] >= $MAX_FAILS_PER_ACCOUNT) {
                    $error = 'Too many failed attempts for this account. Please try again in 15 minutes or visit the registrar.';
                }
            }

            if (!$error) {
                $match = $stu
                    && $stu['status'] === 'approved'
                    && $stu['birthday'] === $f['birthday']
                    && strtolower($stu['email']) === $f['email']
                    && $stu['contact_number'] === $f['contact_number'];

                if (!$match) {
                    reset_failed();
                    if ($stu) {
                        $l = $conn->prepare("INSERT INTO activity_logs (actor_role, actor_name, action) VALUES ('student', ?, 'Failed password reset attempt')");
                        $l->bind_param("s", $stu['full_name']); $l->execute();
                    }
                    // Same message for every mismatch, so nobody can tell which detail was wrong
                    $error = "The details you entered don't match our records. Check them and try again, or visit the registrar to reset your password.";
                } else {
                    $hash = password_hash($pw, PASSWORD_DEFAULT);
                    $u = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
                    $u->bind_param("si", $hash, $stu['id']); $u->execute();

                    $l = $conn->prepare("INSERT INTO activity_logs (actor_role, actor_name, action) VALUES ('student', ?, 'Reset password (Forgot Password)')");
                    $l->bind_param("s", $stu['full_name']); $l->execute();

                    unset($_SESSION['reset_fail'], $_SESSION['reset_fail_at']);
                    flash_set('ok', 'Password changed. You can now log in with your new password.');
                    header("Location: index.php");
                    exit;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot Password · University Enrollment Portal</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="stylesheet" href="assets/css/style.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head><body>
<div class="split">
  <div class="left">
    <div class="brand">
      <img class="logo-img" src="assets/img/logo.png" alt="School logo" width="44" height="44">
      <div><b>University Enrollment System</b><small>Student Portal</small></div>
    </div>
    <div>
      <span class="eyebrow hide-sm">Account Recovery</span>
      <h1>Forgot your password?</h1>
      <div class="mu-dark hide-sm">Confirm it's you with the details you gave when you registered, then choose a new password.</div>
      <ul class="feat hide-sm">
        <li>All four details must match your record</li>
        <li>New password: 8+ characters with a letter and a number</li>
        <li>Every reset is saved in the activity log</li>
      </ul>
    </div>
    <div class="info-box hide-sm">
      <div class="mu-dark">Can't remember your details?</div>
      <div style="margin-top:6px">Visit the registrar and ask for a password reset.</div>
    </div>
  </div>
  <div class="right"><div class="box">
    <div class="box-head">
      <span class="eyebrow">Student Account</span>
      <h1>Reset password</h1>
      <div class="mu">Enter the details you used when you registered.</div>
    </div>
    <?php if ($error): ?><div class="err" role="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" id="resetForm" novalidate style="margin-top:8px">
      <?= csrf_field() ?>
      <label for="student_id">Student ID</label>
      <input id="student_id" name="student_id" placeholder="e.g. 20250775-C" maxlength="10" value="<?= e($f['student_id']) ?>" autofocus required>
      <label for="birthday">Birthday</label>
      <input id="birthday" name="birthday" type="date" max="<?= date('Y-m-d') ?>" value="<?= e($f['birthday']) ?>" required>
      <label for="email">Registered email</label>
      <input id="email" name="email" type="email" maxlength="100" value="<?= e($f['email']) ?>" required>
      <label for="contact_number">Contact number</label>
      <input id="contact_number" name="contact_number" type="tel" inputmode="numeric" maxlength="11" placeholder="09123456789"
             value="<?= e($f['contact_number']) ?>" required oninput="this.value=this.value.replace(/[^0-9]/g,'')">
      <label for="password">New password</label>
      <input id="password" name="password" type="password" data-pw minlength="8" maxlength="72" autocomplete="new-password" placeholder="At least 8 characters, letters and numbers" required>
      <label for="confirm_password">Confirm new password</label>
      <input id="confirm_password" name="confirm_password" type="password" data-pw maxlength="72" autocomplete="new-password" placeholder="Re-enter new password" required>
      <button class="full" type="submit">Change password</button>
    </form>
    <div class="auth-foot mu"><a href="index.php">← Back to login</a></div>
  </div></div>
</div>
<script src="assets/js/password.js"></script>
<script>
(function () {
  var f = document.getElementById('resetForm');
  var rules = {
    student_id:     function (v) { return /^[0-9]{8}-[A-Za-z]$/.test(v.trim()) ? '' : 'Enter a valid Student ID (e.g. 20250775-C).'; },
    birthday:       function (v) { return !v ? 'Please enter your birthday.' : (new Date(v) > new Date() ? 'Birthday cannot be in the future.' : ''); },
    email:          function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Please enter a valid email address.'; },
    contact_number: function (v) { return /^09[0-9]{9}$/.test(v) ? '' : 'Enter 11 digits starting with 09 (e.g. 09123456789).'; },
    password:       function (v) {
      if (v.length < 8) return 'Password must be at least 8 characters.';
      return (/[A-Za-z]/.test(v) && /[0-9]/.test(v)) ? '' : 'Password needs at least one letter and one number.';
    },
    confirm_password: function (v) { return v === f.elements.password.value ? '' : 'Passwords do not match.'; }
  };
  function box(el) {
    var wrap = el.parentNode.classList.contains('pw') ? el.parentNode : el;
    var m = wrap.nextElementSibling;
    if (!m || !m.hasAttribute('data-auto')) {
      m = document.createElement('div'); m.className = 'field-err'; m.setAttribute('data-auto', '1');
      wrap.insertAdjacentElement('afterend', m);
    }
    return m;
  }
  function check(n) {
    var el = f.elements[n], msg = rules[n](el.value), m = box(el);
    el.classList.toggle('invalid', !!msg); m.textContent = msg; m.classList.toggle('show', !!msg);
    return !msg;
  }
  Object.keys(rules).forEach(function (n) {
    f.elements[n].addEventListener('blur', function () { check(n); });
    f.elements[n].addEventListener('input', function () { if (this.classList.contains('invalid')) check(n); });
  });
  f.addEventListener('submit', function (ev) {
    f.elements.student_id.value = f.elements.student_id.value.trim().toUpperCase();
    var first = null;
    Object.keys(rules).forEach(function (n) { if (!check(n) && !first) first = f.elements[n]; });
    if (first) { ev.preventDefault(); first.focus(); }
  });
})();
</script>
</body></html>

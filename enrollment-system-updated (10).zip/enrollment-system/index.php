<?php
// STUDENT LOGIN — only student accounts can sign in here.
// Staff / Admin / Superadmin use staff-login.php.
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

// Already logged in? Go to your own dashboard.
if (isset($_SESSION['role'])) { header("Location: " . dashboard_url_for($_SESSION['role'])); exit; }

$error = '';
$id = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = strtoupper(trim($_POST['user_id'] ?? ''));
    $pass = $_POST['password'] ?? '';

    if (login_locked()) {
        $error = 'Too many failed attempts. Please wait ' . ceil(LOGIN_LOCK_SECONDS / 60) . ' minutes and try again.';
    } elseif ($id === '' || $pass === '') {
        $error = 'Please enter your Student ID and password.';
    } elseif (!preg_match('/^[0-9]{8}-[A-Z]$/', $id)) {
        $error = 'Student ID format is invalid. It looks like 20250775-C.';
    } elseif (strlen($pass) > 72) {
        $error = 'Invalid Student ID or password.';
    } else {
        $stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $student = $stmt->get_result()->fetch_assoc();

        if ($student && password_verify($pass, $student['password'])) {
            if ($student['status'] === 'pending') {
                $error = 'Your registration is still pending Staff approval. Please wait for confirmation.';
            } elseif ($student['status'] === 'rejected') {
                $error = 'Your registration was rejected. Please contact the registrar.';
            } else {
                session_regenerate_id(true);
                login_reset();
                $_SESSION['role'] = 'student';
                $_SESSION['id'] = $student['id'];
                $_SESSION['full_name'] = $student['full_name'];
                $_SESSION['student_id'] = $student['student_id'];
                log_activity($conn, "Logged in");
                header("Location: student/dashboard.php");
                exit;
            }
        } else {
            login_failed();
            $error = 'Invalid Student ID or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student Log in · University Enrollment Portal</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="stylesheet" href="assets/css/style.css?v=<?= (int)@filemtime(__DIR__ . '/assets/css/style.css') ?>">
</head><body>
<div class="split">
  <div class="left">
    <div class="brand">
      <img class="logo-img" src="assets/img/logo.png" alt="School logo" width="44" height="44">
      <div><b>University Enrollment System</b><small>Student Portal</small></div>
    </div>
    <div>
      <span class="eyebrow hide-sm">Online Enrollment</span>
      <h1>Your enrollment, all in one portal.</h1>
      <div class="mu-dark hide-sm">Register, choose your subjects, and view your class schedule — anytime.</div>
      <ul class="feat hide-sm">
        <li>Track your enrollment status</li>
        <li>View your class schedule</li>
        <li>Pick subjects for your course</li>
      </ul>
    </div>
    <div class="info-box hide-sm">
      <div class="mu-dark">Student ID format</div>
      <div class="id">20250775-C</div>
      <div class="mu-dark">Year · student number · program letter</div>
    </div>
  </div>
  <div class="right"><div class="box">
    <div class="box-head">
      <span class="eyebrow">Student Login</span>
      <h1>Welcome back</h1>
      <div class="mu">Log in with your Student ID.</div>
    </div>
    <?= flash_show() ?>
    <?php if ($error): ?><div class="err" role="alert"><?= e($error) ?></div><?php endif; ?>
    <form method="POST" id="loginForm" novalidate style="margin-top:8px">
      <?= csrf_field() ?>
      <label for="user_id">Student ID</label>
      <input id="user_id" name="user_id" placeholder="e.g. 20250775-C" maxlength="10" autocomplete="username"
             value="<?= e($id) ?>" autofocus required>
      <div class="field-err" data-for="user_id">Enter a valid Student ID (e.g. 20250775-C).</div>
      <label for="password">Password</label>
      <input id="password" name="password" type="password" data-pw maxlength="72" autocomplete="current-password" placeholder="Enter your password" required>
      <div class="field-err" data-for="password">Please enter your password.</div>
      <div style="text-align:right;margin-top:8px"><a href="forgot-password.php">Forgot password?</a></div>
      <button class="full" type="submit">Log in</button>
    </form>
    <div class="auth-foot mu">
      No account yet? <a href="register.php">Create an account</a><br>
      <span style="display:inline-block;margin-top:8px">Staff or Admin? <a href="staff-login.php">Go to the Staff login</a></span>
    </div>
  </div></div>
</div>
<script src="assets/js/password.js"></script>
<script>
document.getElementById('loginForm').addEventListener('submit', function (ev) {
  var bad = false;
  var idEl = document.getElementById('user_id'), pwEl = document.getElementById('password');
  idEl.value = idEl.value.trim().toUpperCase();
  var idBad = !/^[0-9]{8}-[A-Z]$/.test(idEl.value);
  var pwBad = pwEl.value === '';
  [[idEl, idBad, 'user_id'], [pwEl, pwBad, 'password']].forEach(function (x) {
    x[0].classList.toggle('invalid', x[1]);
    document.querySelector('[data-for="' + x[2] + '"]').classList.toggle('show', x[1]);
    if (x[1]) bad = true;
  });
  if (bad) ev.preventDefault();
});
</script>
</body></html>

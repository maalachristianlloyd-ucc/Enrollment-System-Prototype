<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('staff');
$role = 'staff'; $active = 'Pending Registrations';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)($_POST['student_id'] ?? 0);
    $decision = $_POST['decision'] ?? '';

    if (!in_array($decision, ['approve', 'reject'], true)) {
        flash_set('err', 'Invalid action.');
        redirect_back();
    }
    $status = $decision === 'approve' ? 'approved' : 'rejected';

    // Only pending registrations can be decided
    $q = $conn->prepare("SELECT full_name FROM students WHERE id = ? AND status = 'pending'");
    $q->bind_param("i", $id); $q->execute();
    $stu = $q->get_result()->fetch_assoc();

    if (!$stu) {
        flash_set('err', 'That registration was not found or has already been decided.');
    } else {
        $stmt = $conn->prepare("UPDATE students SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id); $stmt->execute();
        log_activity($conn, ucfirst($status) . " registration of {$stu['full_name']}");
        flash_set('ok', $stu['full_name'] . ($status === 'approved' ? ' approved — can now log in.' : ' registration rejected.'));
    }
    redirect_back();
}

$programs = program_codes();
$fc = allowed_get('course', $programs);
$where = ["status = 'pending'"]; $params = []; $types = '';
if ($fc !== '') { $where[] = 'program = ?'; $params[] = $fc; $types .= 's'; }
$filters = ['course' => ['All courses', array_combine($programs, $programs)]];

$lt = list_query($conn, [
    'select'   => '*',
    'from'     => 'students',
    'where'    => $where, 'params' => $params, 'types' => $types,
    'search'   => ['full_name', 'student_id', 'program', 'email'],
    'sortable' => ['id' => 'student_id', 'name' => 'full_name', 'program' => 'program', 'email' => 'email', 'date' => 'created_at'],
    'default_sort' => 'date', 'default_dir' => 'desc',
]);
echo page_head('Pending Registrations');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Pending Registrations</h1><span class="badge">Staff Portal</span></div>
  <?= flash_show() ?>

  <div class="card">
    <?= list_toolbar($lt, 'Search name, ID, course or email', $filters) ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'id', 'Student ID (pending)') ?><?= sort_th($lt, 'name', 'Name') ?><?= sort_th($lt, 'program', 'Program') ?><th>Year</th><?= sort_th($lt, 'email', 'Email') ?><?= sort_th($lt, 'date', 'Registered') ?><th>Action</th></tr>
      <?php if (!$lt['rows']) echo empty_row(7, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $p): ?>
        <tr>
          <td><?= e($p['student_id']) ?></td>
          <td><?= e($p['full_name']) ?></td>
          <td><?= e($p['program']) ?></td>
          <td><?= e($p['year_level']) ?></td>
          <td><?= e($p['email']) ?></td>
          <td><?= e($p['created_at']) ?></td>
          <td>
            <?php foreach (['approve' => ['Approve', ''], 'reject' => ['Reject', 'bad']] as $d => [$lbl, $cls]): ?>
              <form method="POST" class="inline-form" data-confirm="<?= e(($d === 'approve' ? 'Approve' : 'Reject') . ' the registration of ' . $p['full_name'] . ' (' . $p['student_id'] . ')?') ?>" data-confirm-title="<?= $d === 'approve' ? 'Approve registration' : 'Reject registration' ?>" data-confirm-btn="<?= $lbl ?>" <?= $d === 'reject' ? 'data-confirm-style="danger"' : '' ?>>
                <?= csrf_field() ?>
                <input type="hidden" name="student_id" value="<?= (int)$p['id'] ?>">
                <input type="hidden" name="decision" value="<?= $d ?>">
                <button class="<?= $cls ?>" type="submit"><?= $lbl ?></button>
              </form>
            <?php endforeach; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
</div>
</div></body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('staff');
$role = 'staff'; $active = 'Dashboard';

$pendingCount = $conn->query("SELECT COUNT(*) c FROM students WHERE status='pending'")->fetch_assoc()['c'];
$totalStudents = $conn->query("SELECT COUNT(*) c FROM students WHERE status='approved'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<title>Staff Dashboard</title><link rel="stylesheet" href="<?= BASE_PATH ?>/assets/css/style.css"></head>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Dashboard</h1><span class="badge">Staff Portal</span></div>

  <div class="grid">
    <div class="card"><div class="mu">Pending Registrations</div><div class="num"><?= $pendingCount ?></div></div>
    <div class="card"><div class="mu">Total Students</div><div class="num"><?= $totalStudents ?></div></div>
  </div>

  <div class="card">
    <?php if ($pendingCount > 0): ?>
      <h3>🔔 New student registration<?= $pendingCount>1?'s':'' ?> waiting for approval</h3>
      <a class="btn" href="pending.php">Review Now</a>
    <?php else: ?>
      <span class="mu">No pending registrations right now.</span>
    <?php endif; ?>
  </div>
</div>
</div></body></html>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_role('staff');
$role = 'staff'; $active = 'Search Students';

$programs = program_codes();
$secOpts = ['none' => 'Unassigned'];
foreach ($conn->query("SELECT id, name FROM sections ORDER BY name") as $sc) $secOpts[(string)$sc['id']] = $sc['name'];
$fc = allowed_get('course', $programs);
$fs = allowed_get('section', array_map('strval', array_keys($secOpts)));
$where = ["s.status = 'approved'"]; $params = []; $types = '';
if ($fc !== '') { $where[] = 's.program = ?'; $params[] = $fc; $types .= 's'; }
if ($fs === 'none') { $where[] = 's.section_id IS NULL'; }
elseif ($fs !== '') { $where[] = 's.section_id = ?'; $params[] = (int)$fs; $types .= 'i'; }
$filters = ['course' => ['All courses', array_combine($programs, $programs)], 'section' => ['All sections', $secOpts]];

$lt = list_query($conn, [
    'select'   => 's.*, sec.name AS section_name',
    'from'     => 'students s LEFT JOIN sections sec ON s.section_id = sec.id',
    'where'    => $where, 'params' => $params, 'types' => $types,
    'search'   => ['s.full_name', 's.student_id', 's.program', 'sec.name'],
    'sortable' => ['id' => 's.student_id', 'name' => 's.full_name', 'program' => 's.program', 'section' => 'sec.name'],
    'default_sort' => 'name',
]);
echo page_head('Search Students');
?>
<body><div class="shell">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main">
  <div class="top"><h1>Search Students</h1><span class="badge">Staff Portal</span></div>
  <div class="card">
    <?= list_toolbar($lt, 'Search approved students (name, ID, course)', $filters) ?>
    <div class="tw"><table>
      <tr><?= sort_th($lt, 'id', 'ID') ?><?= sort_th($lt, 'name', 'Name') ?><?= sort_th($lt, 'program', 'Program') ?><?= sort_th($lt, 'section', 'Section') ?></tr>
      <?php if (!$lt['rows']) echo empty_row(4, $lt['q']); ?>
      <?php foreach ($lt['rows'] as $s): ?>
        <tr>
          <td><?= e($s['student_id']) ?></td><td><?= e($s['full_name']) ?></td>
          <td><?= e($s['program']) ?></td><td><?= e($s['section_name'] ?? 'Unassigned') ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?= list_pagination($lt) ?>
  </div>
</div>
</div></body></html>
